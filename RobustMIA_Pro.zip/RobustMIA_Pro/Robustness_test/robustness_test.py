import numpy as np
from PyQt5.QtCore import pyqtSignal, QObject


class ProgressSignal(QObject):
    progress = pyqtSignal(int)


class RobustnessTest:
    progressSignal = ProgressSignal()

    method_list = ['Gaussian_Noise', "Speckle_Noise", 'ELD_Noise',

                   'Gaussian_Blur', 'Motion_Blur', 'Jpeg_Compression', 'Pixelate',

                   'Brightness', 'Brightness', 'Contrast', 'Contrast',
                   'Saturation', 'Saturation',
                   'Hue', 'Hue', 'Hue',

                   'Rotation',
                   'Translation', 'Translation', 'Translation', 'Translation',
                   'Rescale', 'Rescale', 'Rescale',
                   'Distortion', 'Distortion',

                   'FGSM_Targeted', 'FGSM_Defined', 'MIM_Targeted', 'MIM_Defined',
                   'PGD_Targeted', 'PGD_Defined', 'CW_Targeted', 'CW_Defined',
                   'DDN_Targeted', 'DDN_Defined', 'ERFGSM_Targeted', 'ERFGSM_Defined']

    def __init__(self):
        self.parameter_list = [
            {'Gaussian_Noise': [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5]},
            {'Speckle_Noise': [0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1, 1.125, 1.25]},
            {'ELD_Noise': [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5]},
            {"Gaussian_Blur": [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5]},
            {"Motion_Blur": [5, 11, 15, 21, 25, 31, 35, 41, 45, 51]},
            {"Jpeg_Compression": [35, 29, 24, 20, 17, 14, 11, 9, 7, 5]},
            {"Pixelate": [0.55, 0.5, 0.45, 0.4, 0.35, 0.3, 0.25, 0.2, 0.15, 0.1]},
            {"Brightness__up": [0.85, 0.8, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5, 0.45, 0.4]},
            {"Brightness__down": [1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5]},
            {"Contrast__up": [1.125, 1.25, 1.375, 1.5, 1.625, 1.75, 1.875, 2, 2.125, 2.25]},
            {"Contrast__down": [0.925, 0.85, 0.775, 0.7, 0.625, 0.55, 0.475, 0.4, 0.325, 0.25]},
            {"Saturation__up": [1.125, 1.25, 1.375, 1.5, 1.625, 1.75, 1.875, 2, 2.125, 2.25]},
            {"Saturation__down": [0.925, 0.85, 0.775, 0.7, 0.625, 0.55, 0.475, 0.4, 0.325, 0.25]},
            {"Hue__r": [(1.05, 0.95, 0.95), (1.1, 0.9, 0.9), (1.15, 0.85, 0.85), (1.2, 0.8, 0.8), (1.25, 0.75, 0.75),
                        (1.3, 0.7, 0.7), (1.35, 0.65, 0.65), (1.4, 0.6, 0.6), (1.45, 0.55, 0.55), (1.5, 0.5, 0.5)]},
            {"Hue__g": [(0.95, 1.05, 0.95), (0.9, 1.1, 0.9), (0.85, 1.15, 0.85), (0.8, 1.2, 0.8), (0.75, 1.25, 0.75),
                        (0.7, 1.3, 0.7), (0.65, 1.35, 0.65), (0.6, 1.4, 0.6), (0.55, 1.45, 0.55), (0.5, 1.5, 0.5)]},
            {"Hue__b": [(0.95, 0.95, 1.05), (0.9, 0.9, 1.1), (0.85, 0.85, 1.15), (0.8, 0.8, 1.2), (0.75, 0.75, 1.25),
                        (0.7, 0.7, 1.3), (0.65, 0.65, 1.35), (0.6, 0.6, 1.4), (0.55, 0.55, 1.45), (0.5, 0.5, 1.5)]},
            {"Rotation": [33, 66, 98, 131, 164, 196, 229, 262, 294, 327]},
            {"Translation__x+": [(0.05, 0), (0.1, 0), (0.15, 0), (0.2, 0), (0.25, 0),
                                 (0.3, 0), (0.35, 0), (0.4, 0), (0.45, 0), (0.5, 0)]},
            {"Translation__x-": [(-0.05, 0), (-0.1, 0), (-0.15, 0), (-0.2, 0), (-0.25, 0),
                                 (-0.3, 0), (-0.35, 0), (-0.4, 0), (-0.45, 0), (-0.5, 0)]},
            {"Translation__y+": [(0, 0.05), (0, 0.1), (0, 0.15), (0, 0.2), (0, 0.25),
                                 (0, 0.3), (0, 0.35), (0, 0.4), (0, 0.45), (0, 0.5)]},
            {"Translation__y-": [(0, -0.05), (0, -0.1), (0, -0.15), (0, -0.2), (0, -0.25),
                                 (0, -0.3), (0, -0.35), (0, -0.4), (0, -0.45), (0, -0.5)]},
            {"Rescale__x": [(0.95, 1), (0.9, 1), (0.85, 1), (0.8, 1), (0.75, 1),
                            (0.7, 1), (0.65, 1), (0.6, 1), (0.55, 1), (0.5, 1)]},
            {"Rescale__y": [(1, 0.95), (1, 0.9), (1, 0.85), (1, 0.8), (1, 0.75),
                            (1, 0.7), (1, 0.65), (1, 0.6), (1, 0.55), (1, 0.5)]},
            {"Rescale__xy": [(0.95, 0.95), (0.9, 0.9), (0.85, 0.85), (0.8, 0.8), (0.75, 0.75),
                             (0.7, 0.7), (0.65, 0.65), (0.6, 0.6), (0.55, 0.55), (0.5, 0.5)]},
            {"Distortion(Barrel)": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]},
            {"Distortion(Pincushion)": [-0.1, -0.2, -0.3, -0.4, -0.5, -0.6, -0.7, -0.8, -0.9, -1]},
            {"FGSM_Targeted": [1 / 255, 2 / 255, 3 / 255, 4 / 255, 5 / 255, 6 / 255, 7 / 255, 8 / 255, 9 / 255,
                               10 / 255]},
            {"FGSM_Defined": [1 / 255, 2 / 255, 3 / 255, 4 / 255, 5 / 255, 6 / 255, 7 / 255, 8 / 255, 9 / 255,
                              10 / 255]},
            {"MIM_Targeted": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]},
            {"MIM_Defined": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]},
            {"PGD_Targeted": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]},
            {"PGD_Defined": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]},
            {"CW_Targeted": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]},
            {"CW_Defined": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]},
            {"DDN_Targeted": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]},
            {"DDN_Defined": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]},
            {"ERFGSM_Targeted": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]},
            {"ERFGSM_Defined": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]},
        ]
        self.num_parameters = len(self.parameter_list[0]['Gaussian_Noise'])
        print('参数数目：', self.num_parameters)

    @classmethod
    def get_point_line_data(cls, p, max_p):
        max_p = float(max_p)
        # 稳定率
        static_rate = np.array(p)/max_p
        # 插入原图稳定率：100%
        static_rate = np.insert(static_rate, 0, 1)
        static_rate[static_rate > 1] = 1

        # 扰动边界（int）
        r_boundary = cls.get_r_boundary(static_rate)

        static_rate = list(static_rate)
        static_rate = [float(i) for i in static_rate]

        return static_rate, r_boundary

    @classmethod
    def get_r_boundary(cls, static_rate, rate=0.5):
        # index_: (按行，按列)
        index_ = np.where(static_rate <= rate)[0]
        if len(index_) == 0:
            r_boundary = -1
        else:
            r_boundary = int(index_[0])

        return r_boundary

    # 计算模型稳定性分数
    @classmethod
    def get_score(cls, static_rate, r_boundary) -> (float, float):
        score0 = np.mean(static_rate[1:])
        if r_boundary == -1:
            score1 = 1.0
        else:
            score1 = (r_boundary-1)/10.0

        return score0, score1

    @classmethod
    def get_radar_data(cls, score_list):
        score_list = np.array(score_list)
        # 原本结构为[[稳定率平均得分，最大强度得分],
        #          [稳定率平均得分，最大强度得分]，
        #            36个
        #          []]
        score_list = score_list.T
        # 此时结构为[[稳定率平均得分，稳定率平均得分，36个...],
        #          [强度得分，强度得分，...]]
        index_list = {}
        for i, method in enumerate(cls.method_list):
            if method.endswith('_Targeted'):
                method = method[:-9]
            if method.endswith('_Defined'):
                method = method[:-8]

            if method in index_list.keys():
                index_list[method].append(i)
            else:
                index_list[method] = [i]

        score_list_new = [[],[]]
        for method, index in index_list.items():
            # [[i]]，[i] = index
            score_list_new[0].append(np.mean(score_list[0][index], axis=0)*100)
            score_list_new[1].append(np.mean(score_list[1][index], axis=0)*100)

        return score_list_new

    @classmethod
    def get_score_sum(cls, radar_data):
        score_sum = 0.0
        score_max = 0.0
        method_weight = [
            1/3, 1/3, 1/3,
            1/4, 1/4, 1/4, 1/4,
            1/4, 1/4, 1/4, 1/4,
            1/4, 1/4, 1/4, 1/4,
            2/6, 2/6, 2/6, 2/6, 2/6, 2/6
        ]

        for i in range(len(radar_data)):
            for j in range(len(radar_data[i])):
                score_sum += radar_data[i][j]*method_weight[j]
                score_max += method_weight[j] * 100

        score_sum = (score_sum / score_max) * 10000
        score_sum = int(score_sum)
        return score_sum


if __name__ == '__main__':
    # rt = RobustnessTest()
    # p = [0.9,0.75,0.5,0.25]
    # max_p = 0.9
    # print(rt.get_point_line_data(p,max_p))

    score_list = np.array([[80,70], [80,70], [80,70]])
    print(score_list.T)
    print(np.mean(score_list[0][[0]], axis=0) * 100)
