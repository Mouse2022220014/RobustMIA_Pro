import gc
from Model_prediction.Detection import Detection_prediction
from Robustness_test.robustness_test import RobustnessTest


class DetectionTest(RobustnessTest):
    def __init__(self, session, **kwargs):
        super().__init__()

        self.session = session
        self.detection_pred = Detection_prediction(self.session)

    def full_proces_testing(self):
        # 发送信号
        self.progressSignal.progress.emit(0)

        point_line_data = []
        score_list = []
        max_p = self.detection_pred.max_p
        for i in range(len(self.method_list)):
            print('项目', i + 1)
            self.progressSignal.progress.emit(i + 1)
            p, predict_save, image_save, label_save = self.detection_pred.predict(self.method_list[i],
                                                                                  self.parameter_list[i])
            point_line = self.get_point_line_data(p, max_p)
            point_line_data.append(point_line)
            score_list.append(list(self.get_score(*point_line)))
            # image_list.append(self.detection_pred.get_image(image_save, predict_save, label_save, index_save))

        radar_data = self.get_radar_data(score_list)
        score_sum = self.get_score_sum(radar_data)

        del self.detection_pred
        gc.collect()
        return point_line_data, radar_data, score_sum

