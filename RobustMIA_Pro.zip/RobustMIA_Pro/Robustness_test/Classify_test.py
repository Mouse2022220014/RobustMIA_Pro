import gc
from Model_prediction.Classify import Classify_prediction
from Robustness_test.robustness_test import RobustnessTest



class ClassifyTest(RobustnessTest):
    def __init__(self, session, **kwargs):
        super().__init__()

        self.session = session
        self.classify_pred = Classify_prediction(self.session)

    def full_proces_testing(self):
        self.progressSignal.progress.emit(0)

        # 扰动边界列表[(稳定率，扰动边界)]
        point_line_data = []
        # 得分列表
        score_list = []
        # 示例图像列表
        images_list = []  # [[11], [11], [11], ... ] 36组

        max_p = self.classify_pred.max_p

        # 遍历方法列表攻击图像并预测
        for i in range(len(self.method_list)):
            # 发送信号更新页面
            print('项目', i+1)
            self.progressSignal.progress.emit(i+1)

            p, predict_save, images_save, label_save, index_save = self.classify_pred.predict(self.method_list[i], self.parameter_list[i])

            images_list.append(self.classify_pred.get_images(images_save, label_save, predict_save, index_save))
            point_line = self.get_point_line_data(p, max_p)
            # [1, 0.9, 0.85 ... 10个]
            point_line_data.append(point_line)
            # [[[p1],r],[[p2],r],36个]

            score = self.get_score(*point_line)  # 强度平均得分，极端值得分）
            score_list.append(list(score))

        radar_data = self.get_radar_data(score_list)
        # [[稳定率平均得分，平均得分], [强度得分，强度得分]]
        score_sum = self.get_score_sum(radar_data)

        del self.classify_pred
        gc.collect()

        return point_line_data, radar_data, score_sum, images_list


if __name__ == '__main__':
    session = {'username': 'wzk', 'model_name': 'model', 'model_type': 'classification'}
    ct = ClassifyTest(session)

    p, score_sum, score_list = ct.full_proces_testing()
    print('模型稳定性分数为', score_sum)
