import gc

from Robustness_test.robustness_test import RobustnessTest
from Model_prediction.Segmentation import Segmentation_prediction


class SegmentationTest(RobustnessTest):
    def __init__(self, session, **kwargs):
        super().__init__()
        self.conn = None
        try:
            self.conn = kwargs['conn']
        except KeyError:
            print('未设置运行设备ip，将在本机进行测试...')

        self.session = session
        self.segmentation_pred = Segmentation_prediction(self.session)

    def full_proces_testing(self):
        self.progressSignal.progress.emit(0)
        point_line_data = []
        image_list = []
        score_list = []
        max_p = self.segmentation_pred.max_p
        for i in range(len(self.method_list)):
            # 发送信号更新页面
            print("项目", i + 1)
            if self.conn is None:
                self.progressSignal.progress.emit(i + 1)

            else:
                # socket通讯
                self.conn.send(str(i + 1).encode())

            p, image_save, predict_save, label_save, index_save = self.segmentation_pred.predict(self.method_list[i],
                                                                                                 self.parameter_list[i])
            image_list.append(self.segmentation_pred.get_image(image_save, label_save, predict_save, index_save))

            point_line = self.get_point_line_data(p, max_p)
            point_line_data.append(point_line)
            score_list.append(list(self.get_score(*point_line)))

        radar_data = self.get_radar_data(score_list)
        score_sum = self.get_score_sum(radar_data)

        gc.collect()
        return point_line_data, radar_data, score_sum, image_list

