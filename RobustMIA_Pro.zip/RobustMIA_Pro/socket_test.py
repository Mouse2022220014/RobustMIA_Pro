import socket
import json
import zipfile
import os


def zip_folder(folder_path: str, output_path: str):
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, folder_path))


if __name__ == "__main__":
    # host_name = socket.gethostname()
    # ip = socket.gethostbyname(host_name)
    # print(host_name, ip)
    # ip = '172.17.25.141'
    # client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # try:
    #     # 尝试连接到设备
    #     client_socket.connect(('192.168.80.206', 5000))
    #     print("成功连接到设备")
    #
    # except Exception as e:
    #     print("连接时出现错误:", e)
    # session = {'name': 'wzk'}
    # client_socket.send(str.encode('receive_session'))
    # client_socket.send(json.dumps(session).encode())
    #
    # client_socket.close()
    # zip_folder('./classification/wzk/data', './segmentation/data.zip')
    pass
