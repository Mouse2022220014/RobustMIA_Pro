import torch
from PIL import Image
import numpy as np
import os
import torchvision.transforms as transforms


class Image_segmentation:
    def __init__(self, path):
        self.item = []

        img_end = ('jpg', 'bmp', 'png', 'jpeg', 'rgb', 'tif', 'tiff', 'gif', 'GIF', 'webp', 'ppm')
        image_names = os.listdir(os.path.join(path, 'image'))

        for i in range(len(image_names)):
            image_path = os.path.join(path, 'image', image_names[i])
            label_path = os.path.join(path, 'label', image_names[i].split('.')[0] + '.png')

            if any(image_path.endswith(m) for m in img_end):
                image = Image.open(image_path).convert('RGB')
                image = transforms.ToTensor()(image)

                label = Image.open(label_path).convert('L')
                label = transforms.ToTensor()(label)
                label = label * 255

                if label.shape[0] > 1:
                    label = transforms.Grayscale()(label)
                self.item.append([image, label.long()])

        # 检查打包是否正确

    def __getitem__(self, index):
        return self.item[index]

    def __len__(self):
        return len(self.item)

    def __iter__(self):
        return iter(self.item)



