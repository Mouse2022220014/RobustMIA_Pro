import os
import xml.etree.ElementTree as ET
import torch
from PIL import Image
from torchvision.transforms import transforms


# 重写获取检测voc数据集,直接读取到内存中，方便多用户并行
class Voc_detection:
    def __init__(self, path, model_handler):
        try:
            # 防呆设计,path下如果只有一个文件夹，直接把该文件夹作为path，防止用户打包zip文件时，把文件夹也打包进去
            if len(os.listdir(path)) == 1 and os.path.isdir(os.path.join(path, os.listdir(path)[0])):
                path = os.path.join(path, os.listdir(path)[0])

            # 初始化item
            self.item = []
            if not os.path.exists(path):  # 判断文件是否存在
                print("not found any img file in {}".format(path))
            img_end = ('jpg', 'bmp', 'png', 'jpeg', 'rgb', 'tif', 'tiff', 'gif', 'GIF', 'webp', 'ppm')
            # 获取文件夹下的文件路径
            image_names = sorted(os.listdir(os.path.join(path, 'JPEGImages')))

            # 读取所有图片到内存中
            self.item = []
            # 检查数据量
            image_len = (5, 20)
            if len(image_names) >= image_len[0]:
                amount = 0
                for image_name in image_names:
                    if amount >= image_len[1]:
                        break

                    if any(image_name.endswith(i) for i in img_end):
                        boxes = []
                        classes = []
                        image = Image.open(os.path.join(path, 'JPEGImages', image_name)).convert('RGB')
                        image = transforms.ToTensor()(image)
                        # image_np = np.array(image, dtype=np.float16)
                        # image = torch.from_numpy(image_np)
                        temp_name = '.'.join(image_name.split('.')[:-1]) + '.xml'
                        anno = ET.parse(os.path.join(path, 'Annotations', temp_name)).getroot()

                        # 读取xml中的box
                        for obj in anno.iter("object"):
                            _box = obj.find("bndbox")
                            box = [
                                _box.find("xmin").text,
                                _box.find("ymin").text,
                                _box.find("xmax").text,
                                _box.find("ymax").text,
                            ]
                            TO_REMOVE = 1  # 由于像素是网格存储，坐标2实质表示第一个像素格，所以-1
                            box = tuple(map(lambda x: x - TO_REMOVE, list(map(float, box))))
                            boxes.append(box)
                            name = obj.find("name").text.strip()
                            classes.append(name)
                        boxes = torch.tensor(boxes, dtype=torch.float16)
                        self.item.append([image, boxes, classes])
                        amount += 1

            else:
                print(f"数据量不足,当前数据量为{len(image_names)}")
        except Exception as e:
            print("上传数据文件错误:{}".format(e))

        # 再次检查数据集长度(以免用户打包错误导致上面读取到的图片实际比len小)
        if len(self.item) < image_len[0]:
            print(f"数据量不足,当前数据量为{len(self.item)}")

        model_handler.check(self.item[0][0].unsqueeze(0), [{"boxes": self.item[0][1], "labels": self.item[0][2]}])

    # 返回数据集的长度
    def __len__(self):
        return len(self.item)

    # 返回数据集中的数据
    def __getitem__(self, index):
        data = self.item[index]
        return data

    def __iter__(self):
        return iter(self.item)

