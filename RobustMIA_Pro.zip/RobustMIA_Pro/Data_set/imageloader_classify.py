import os
from torchvision import transforms
import numpy as np
import torch
from PIL import Image


# 获取分类模型图像数据
class ImageLoader_classify:
    # 为啥不直接搞个静态方法返回item呢
    def __init__(self, path):
        # data and label
        self.item = []

        img_end = ('jpg', 'bmp', 'png', 'jpeg', 'rgb', 'tif', 'tiff', 'gif', 'GIF', 'webp', 'ppm', 'JPEG')
        dir_list = sorted(os.listdir(path))

        for label in dir_list:
            label_path = os.path.join(path, label)
            if os.path.isdir(label_path):
                files = os.listdir(label_path)
                for file in files:
                    file_path = os.path.join(label_path,file)

                    if os.path.isfile(file_path) and any(file_path.endswith(i) for i in img_end):
                        image = Image.open(file_path).convert('RGB')
                        image = transforms.ToTensor()(image)

                        # 为什么label要用列表包裹起来
                        self.item.append([image, [label]])

    def __len__(self):
        return len(self.item)

    def __getitem__(self, index):
        return self.item[index]

    def __iter__(self):
        return iter(self.item)

