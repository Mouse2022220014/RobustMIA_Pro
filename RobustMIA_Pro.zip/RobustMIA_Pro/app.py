from PyQt5.QtWidgets import QApplication
import sys

# 我的模块
from client.mainwindow import HomePage


if __name__ == '__main__':
    session = {'username': 'test_user', 'model_name': 'model', 'model_type': 'classification', 'server_ip': None}
    app = QApplication(sys.argv)

    window = HomePage(session)
    window.show()

    sys.exit(app.exec())
