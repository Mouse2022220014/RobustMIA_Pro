import os
import random
import numpy as np
import cv2
import torch
from torch import nn, optim
import copy
import kornia


def atanh(x):
    return 0.5 * torch.log((1 + x) / (1 - x))


def tanh_space(x):
    return 1 / 2 * (torch.tanh(x) + 1)


def atleast_kd(x, k: int):
    x = x.detach()
    shape = x.shape + (1,) * (k - x.ndim)
    return x.reshape(shape)


def normalize_gradient_l2_norms(grad):
    grad = grad.detach()
    norms = grad.flatten(1).square().sum(axis=-1, keepdims=False).sqrt()

    # avoid division by zero
    norms = torch.maximum(norms, torch.tensor(1e-12))
    factor = 1 / norms
    factor = atleast_kd(factor, grad.ndim)
    return grad * factor


def boxes_batch(func):
    # attack_batch: Attack a batch of images
    def wrapper(self, h, w, bboxs, parameters, *args, **kwargs):
        bboxs_list = []
        for parameter in parameters:
            bboxs_ = func(self, h, w, bboxs, parameter, *args, **kwargs)
            bboxs_list.append(bboxs_)
        return bboxs_list

    return wrapper


class Geometric_box:
    @staticmethod
    def get_corners(bboxes):
        bboxes = bboxes.numpy()
        width = (bboxes[:, 2] - bboxes[:, 0]).reshape(-1, 1)
        height = (bboxes[:, 3] - bboxes[:, 1]).reshape(-1, 1)

        x1 = bboxes[:, 0].reshape(-1, 1)
        y1 = bboxes[:, 1].reshape(-1, 1)

        x2 = x1 + width
        y2 = y1

        x3 = x1
        y3 = y1 + height

        x4 = bboxes[:, 2].reshape(-1, 1)
        y4 = bboxes[:, 3].reshape(-1, 1)
        corners = np.hstack((x1, y1, x2, y2, x3, y3, x4, y4))
        return corners

    @staticmethod
    def get_bboxes(corners):
        x_min = np.min(corners[:, [0, 2, 4, 6]], axis=1).reshape(-1, 1)
        y_min = np.min(corners[:, [1, 3, 5, 7]], axis=1).reshape(-1, 1)
        x_max = np.max(corners[:, [0, 2, 4, 6]], axis=1).reshape(-1, 1)
        y_max = np.max(corners[:, [1, 3, 5, 7]], axis=1).reshape(-1, 1)
        bboxes = np.hstack((x_min, y_min, x_max, y_max))
        bboxes = torch.from_numpy(bboxes)
        return bboxes

    @staticmethod
    def standard_bbox(bboxes, h, w):
        bboxes[:, 0][bboxes[:, 0] < 0] = 0
        bboxes[:, 1][bboxes[:, 1] < 0] = 0
        bboxes[:, 2][bboxes[:, 2] > w] = w
        bboxes[:, 3][bboxes[:, 3] > h] = h
        return bboxes

    @boxes_batch
    def Rotation(cls, h, w, bboxes_, angle=30):
        angle = float(angle)
        cx, cy = w / 2, h / 2
        corners = cls.get_corners(bboxes_)
        corners = corners.reshape(-1, 2)
        corners = corners - np.array([[cx, cy]])
        corners = np.hstack((corners, np.ones((corners.shape[0], 1), dtype=type(corners[0][0]))))

        M = cv2.getRotationMatrix2D((0, 0), angle, 1.0)
        # Prepare the vector to be transformed
        calculated = np.dot(M, corners.T).T
        calculated = calculated + np.array([[cx, cy]])
        calculated = calculated.reshape(-1, 8)
        bboxes = cls.get_bboxes(calculated)
        bboxes = cls.standard_bbox(bboxes, h, w)
        return bboxes

    @boxes_batch
    def Translation(cls, h, w, bboxes_, X_y=(0.2, 0.2)):
        X_y = torch.tensor(X_y)
        X_y = torch.cat((X_y, X_y), dim=0)
        X_y = X_y * torch.tensor([[w, h, w, h]])
        bboxes = bboxes_ + X_y
        bboxes = cls.standard_bbox(bboxes, h, w)
        return bboxes

    @boxes_batch
    def Rescale(cls, h, w, bboxes_, X_y=(0.2, 0.2)):
        cx, cy = w // 2, h // 2
        bboxes = bboxes_ - torch.tensor([[cx, cy, cx, cy]])
        X_y = torch.tensor(X_y)
        X_y = torch.cat((X_y, X_y), dim=0)
        bboxes = bboxes * X_y
        bboxes += torch.tensor([[cx, cy, cx, cy]])
        bboxes = cls.standard_bbox(bboxes, h, w)
        return bboxes

    @boxes_batch
    def Distortion(cls, h, w, bboxes_, k=1.0):
        cx, cy = w // 2, h // 2
        # Generate the camera matrix
        camera_matrix = torch.tensor([[[w, 0, cx],
                                       [0, h, cy],
                                       [0, 0, 1]]], dtype=torch.float)
        corners = cls.get_corners(bboxes_)
        corners = torch.from_numpy(corners)
        corners = corners.reshape(-1, 4, 2)
        calculated = kornia.geometry.calibration.undistort_points(corners, camera_matrix, torch.tensor([[k, k, 0, 0, k]]))
        calculated = calculated.reshape(-1, 8)
        calculated = calculated.numpy()
        bboxes = cls.get_bboxes(calculated)
        bboxes = cls.standard_bbox(bboxes, h, w)
        return bboxes


def attack_batch(func):
    # Get a batch of attacked images
    def wrapper(self, img: torch.Tensor, label, parameters, *args, **kwargs):
        img = img.to(self.device)
        imgs = []
        # 如果是灰度图先转RGB图
        if img.shape[0] == 1:
            img_rgb = img.repeat(3, 1, 1)
        else:
            img_rgb = img

        for parameter in parameters:
            img_ = func(self, img_rgb, parameter, *args, **kwargs)
            img_ = img_.view(img_rgb.shape)
            imgs.append(img_)

        imgs = torch.stack(imgs)
        # 如果img是灰度图，重新转灰度图
        if img.shape[0] == 1:
            imgs = imgs.mean(dim=1, keepdim=True)
        return imgs
    # 别忘了return！！！！！！！！！！！
    return wrapper




class Base_Attack:
    def __init__(self, model, device, model_type='classification'):
        self.model = model
        self.device = device
        self.model_type = model_type


class Noise_Attack(Base_Attack):
    def __init__(self, model, device, model_type, **kwargs):
        super().__init__(model, device, model_type)

    @attack_batch
    def Gaussian_Noise(self, img, std, mean=0):
        # 高斯噪声
        noise = torch.randn_like(img) * std + mean
        out = img + noise
        out = torch.clamp(out, 0, 1)
        return out

    @attack_batch
    def Speckle_Noise(self, img, std, mean=0):
        # 斑点噪声
        noise = torch.randn_like(img) * std + mean
        out = img + img * noise
        out = torch.clamp(out, 0, 1)
        return out

    @attack_batch
    def ELD_Noise(self, img, a=0.0):
        # noise = noisy_shot + noisy_read + noisy_row + noisy_q + noisy_bias
        # 使用泊松噪声作为shot noisy
        noisy_shot = (torch.poisson(img / 2) * 2 - img) / 4

        # 使用高斯噪声作为read noisy
        noisy_read = torch.normal(0, 0.15, img.shape)

        # 使用行噪声作为row noisy
        noisy_row_ = torch.randn(img.shape[0], img.shape[1], 1) * 0.145
        noisy_row = noisy_row_.repeat(1, 1, img.shape[2])  # 沿着第二个维度重复M次

        # 量化噪声
        noisy_q = torch.rand(img.shape) * 0.5 - 0.25

        noisy_shot, noisy_read, noisy_row, noisy_q = noisy_shot.to(self.device), noisy_read.to(
            self.device), noisy_row.to(
            self.device), noisy_q.to(self.device)
        out = img + a * (noisy_shot + noisy_read + noisy_row + noisy_q)
        out = torch.clamp(out, 0, 1)
        return out

class Blur_Attack(Base_Attack):
    def __init__(self, model=None, device=None, model_type='classification', **kwargs):
        super().__init__(model, device, model_type)

    # 高斯模糊
    @attack_batch
    def Gaussian_Blur(self, img, sigma=1, kernel_size=15):
        out = kornia.filters.gaussian_blur2d(img.unsqueeze(0), (kernel_size, kernel_size), (sigma, sigma))
        out.squeeze(0)
        return out

    # 运动模糊
    @attack_batch
    def Motion_Blur(self, img, degree=1, angle=-1):
        if angle == -1:
            angle = torch.rand(1) * 360
        out = kornia.filters.motion_blur(img.unsqueeze(0), degree, torch.tensor([angle]), direction=torch.tensor([1.0]))
        out.squeeze(0)
        return out

    # JPEG压缩
    @attack_batch
    def Jpeg_Compression(self, img, quality=30):
        # 转换为numpy数组
        img_ = (img * 255).cpu().numpy().astype(np.uint8)

        img_ = img_.transpose(1, 2, 0)

        param = [cv2.IMWRITE_JPEG_QUALITY, int(quality)]
        # 编码
        result, encoded_img = cv2.imencode('.jpg', img_, param)
        # 解码
        out = cv2.imdecode(encoded_img, cv2.IMREAD_COLOR)
        # 转换回Tensor
        out = torch.from_numpy(out).to(self.device).float() / 255.0
        out = out.permute(2, 0, 1)
        return out

    # 像素化
    @attack_batch
    def Pixelate(self, img, n=0.6):
        out = kornia.geometry.resize(img.unsqueeze(0), (int(img.shape[1] * n), int(img.shape[2] * n)), interpolation='nearest')
        out = kornia.geometry.resize(out, (int(img.shape[1]), int(img.shape[2])), interpolation='nearest').squeeze(0)
        return out


class Color_Attack(Base_Attack):
    def __init__(self, model=None, device=None, model_type='classification', **kwargs):
        super().__init__(model, device, model_type)

    # Brightness gamma越小亮度越高
    @attack_batch
    def Brightness(self, img, gamma=1):
        out = img ** gamma / gamma ** 0.25
        out = torch.clamp(out, 0, 1)
        return out

    # 对比度 alpha越大对比度越强
    @attack_batch
    def Contrast(self, img, alpha=1):
        out = img * alpha + 0.5 * (1-alpha)
        out = torch.clamp(out, 0, 1)
        return out

    # 饱和度
    @attack_batch
    def Saturation(self, img, alpha=1):
        hsv = kornia.color.rgb_to_hsv(img)
        hsv[1] = hsv[1] * alpha + 0.2 * (1 - alpha)
        out = kornia.color.hsv_to_rgb(hsv)
        out = torch.clamp(out, 0, 1)
        return out

    # 色度
    @attack_batch
    def Hue(self, img, alpha=None):
        alpha = torch.tensor(alpha).to(self.device)
        out = img * alpha.view(3, 1, 1)
        out = torch.clamp(out, 0, 1)
        return out


class Geometric_Attack(Base_Attack):
    def __init__(self, model=None, device=None, model_type='classification', **kwargs):
        super().__init__(model, device, model_type)

    @attack_batch
    def Rotation(self, img, angle=30, flags='bilinear'):
        c, h, w = img.shape
        center = torch.tensor([[w/2, h/2]]).to(self.device)
        angle = torch.tensor(angle).float().to(self.device)

        out = kornia.geometry.rotate(img.unsqueeze(0), angle, center=center, mode=flags).squeeze(0)
        return out

    @attack_batch
    def Translation(self, img, X_y=(0.2, 0.2), flags='bilinear'):
        c, h, w = img.shape
        X_y = torch.tensor(X_y)
        X_y = X_y * torch.tensor([[w,h]]).to(self.device)

        out = kornia.geometry.translate(img.unsqueeze(0), X_y, mode=flags, align_corners=True).squeeze(0)
        return out

    @attack_batch
    def Rescale(self, img, sx_sy=(0.8, 0.8), flags='bilinear'):
        out = kornia.geometry.resize(img.unsqueeze(0), (int(sx_sy[1] * img.shape[1]), int(sx_sy[0] * img.shape[2])),
                                     interpolation=flags)
        out = kornia.geometry.center_crop(out, (int(img.shape[1]), int(img.shape[2]))).squeeze(0)
        return out

    # Distortion
    @attack_batch
    def Distortion(self, image, k=1.0, flags='bilinear'):
        # 对图像进行径向畸变，k越大，畸变越大
        c, height, width = image.shape

        # Generate the camera matrix
        center = (width / 2, height / 2)
        camera_matrix = torch.tensor([[[width, 0, center[0]],
                                       [0, height, center[1]],
                                       [0, 0, 1]]], dtype=torch.float)
        camera_matrix = camera_matrix.to(self.device)
        out = kornia.geometry.calibration.undistort_image(image.unsqueeze(0), camera_matrix,
                                                          torch.tensor([[k, k, 0, 0, k]]).to(self.device)).squeeze(0)
        return out

def attack_batch_with_label(func):
    def wrapper(self, image, label, parameter, *args, **kwargs):
        image = image.to(self.device)
        image = image.unsqueeze(0)

        images = func(self, image, label, parameter, *args, **kwargs)
        images = torch.stack(images)
        return images
    return wrapper

def attack_batch_with_label_(func):
    def wrapper(self, image, label, parameters, *args, **kwargs):
        imgs = []
        image = image.to(self.device)
        image = image.unsqueeze(0)

        for parameter in parameters:
            image_ = func(self, image, label, parameter, *args, **kwargs)
            imgs.append(image_.squeeze(0))

        imgs = torch.stack(imgs)
        return imgs

    return wrapper


class White_Box_Attack(Base_Attack):
    def __init__(self, model=None, device=None, model_type='classification', **kwargs):
        super().__init__(model, device, model_type)
        self.all_labels = kwargs.get('all_labels')

    def get_target_label(self, images, labels):
        if self.model_type == 'classification':
            # 在self.all_labels中随机选取一个不同的label作为目标
            target_label = random.choice(self.all_labels)
            return [target_label]
        elif self.model_type == 'segmentation':
            # 将label转为one-hot编码，打乱one-hot编码的循序，与原来的label不同即可
            temp_result = self.model.forward_pred(images)
            num_classes = temp_result.shape[1]
            one_hot_labels = torch.nn.functional.one_hot(labels.squeeze(1), num_classes=num_classes).permute(0, 3, 1, 2)
            random_index = torch.randperm(num_classes)
            for i in range(len(random_index) - 1):
                while random_index[i] == i:
                    temp_index = random_index[i]
                    random_index[i] = random_index[i + 1]
                    random_index[i + 1] = temp_index
            target_labels = one_hot_labels[:, random_index, :, :]
            target_labels = torch.argmax(target_labels, dim=1).unsqueeze(1)
            return target_labels
        elif self.model_type == 'detection':
            # 随机选取一个不同的label作为目标
            target_labels = copy.deepcopy(labels)
            for target_label, label in zip(target_labels, labels):
                for i in range(len(target_label['labels'])):
                    while target_label['labels'][i] == label['labels'][i]:
                        target_label['labels'][i] = random.choice(
                            [label_ for label_ in self.all_labels if label_ != label['labels'][i]])
            return target_labels


    @attack_batch_with_label
    def FGSM_Targeted(self, image, label, epses=None):
        if epses is None:
            epses = [2 / 255, 4 / 255, 6 / 255, 8 / 255, 10 / 255]

        image_ = image.clone().detach().to(self.device)
        image_.requires_grad = True

        target_label = self.get_target_label(image_, label)
        # 损失
        cost = self.model.forward_loss(image_, copy.deepcopy(target_label))
        # 梯度
        grad = torch.autograd.grad(cost, image_, create_graph=False, retain_graph=False)[0]

        adv_images_list = []

        for eps in epses:
            adv_image = image_ - eps * grad.sign()
            adv_image = torch.clamp(adv_image, 0, 1).detach()
            adv_images_list.append(adv_image.squeeze(0))

        return adv_images_list

    @attack_batch_with_label
    def FGSM_Defined(self, image, label, epses=None):
        if epses is None:
            epses = [2 / 255, 4 / 255, 6 / 255, 8 / 255, 10 / 255]

        image_ = image.clone().detach().to(self.device)
        image_.requires_grad = True

        cost = self.model.forward_loss(image_, copy.deepcopy(label))

        grad = torch.autograd.grad(cost, image_, create_graph=False, retain_graph=False)[0]

        adv_images_list = []

        for eps in epses:
            adv_image = image_ + eps * grad.sign()
            adv_image = torch.clamp(adv_image, 0, 1)
            adv_images_list.append(adv_image.squeeze(0))

        return adv_images_list

    @attack_batch_with_label
    def MIM_Targeted(self, image, label, step=None, eps=8/255., alpha=2/255., decay=1.0):
        if step is None:
            step = [1, 2, 3, 4, 5]

        image_ = image.clone().detach().to(self.device)
        target_label = self.get_target_label(image_, label)

        momentum = torch.zeros_like(image_).detach().to(self.device)
        adv_image = image_.clone().detach().to(self.device)

        adv_images_list = []

        for step in range(step[-1]):
            adv_image.requires_grad = True

            cost = self.model.forward_loss(adv_image, copy.deepcopy(target_label))

            grad = torch.autograd.grad(cost, adv_image, create_graph=False, retain_graph=False)[0]
            grad = grad / torch.mean(torch.abs(grad), dim=(1, 2, 3), keepdim=True)
            grad = grad + momentum * decay
            momentum = grad

            adv_image = adv_image.detach() - grad.sign() * alpha
            # 限制变化范围[-eps,eps]
            delta = torch.clamp(adv_image - image_, min=-eps, max=eps)
            adv_image = torch.clamp(adv_image + delta, 0, 1)

            adv_images_list.append(adv_image.squeeze(0))

        return adv_images_list

    @attack_batch_with_label
    def MIM_Defined(self, image, label, steps=None, eps=8/255., alpha=2/255., decay=1.0):
        if steps is None:
            steps = [1, 2, 3, 4, 5]

        image_ = image.clone().detach().to(self.device)
        adv_image = image_.clone().detach().to(self.device)

        momentum = torch.zeros_like(image_).detach().to(self.device)

        adv_images_list = []

        for step in range(steps[-1]):
            adv_image.requires_grad = True

            cost = self.model.forward_loss(adv_image, copy.deepcopy(label))
            grad = torch.autograd.grad(cost, adv_image, create_graph=False, retain_graph=False)[0]

            grad = grad / torch.mean(torch.abs(grad), dim=(1, 2, 3), keepdim=True)
            grad = grad + momentum * decay
            momentum = grad

            adv_image = adv_image.detach() + grad.sign() * alpha
            # 限制变化范围
            delta = torch.clamp(adv_image - image_, min=-eps, max=eps)
            adv_image = torch.clamp(adv_image + delta, 0, 1)

            adv_images_list.append(adv_image.squeeze(0))

        return adv_images_list

    @attack_batch_with_label
    def PGD_Targeted(self, image, label, steps=None, eps=8/255, alpha=2/255):
        if steps is None:
            steps = [1, 2, 3, 4, 5]

        image_ = image.clone().detach().to(self.device)
        target_label = self.get_target_label(image, label)
        adv_image = image_.clone().detach().to(self.device)
        adv_image = adv_image + torch.empty_like(adv_image).uniform_(-eps, eps)
        adv_image = torch.clamp(adv_image, 0, 1)

        adv_images_list = []

        for step in range(steps[-1]):
            adv_image.requires_grad = True

            cost = self.model.forward_loss(adv_image, copy.deepcopy(target_label))
            grad = torch.autograd.grad(cost, adv_image, create_graph=False, retain_graph=False)[0]

            adv_image = adv_image.detach() - grad.sign() * alpha
            # 限制变化范围
            delta = torch.clamp(adv_image - image_, min=-eps, max=eps)
            adv_image = torch.clamp(adv_image + delta, 0, 1)

            adv_images_list.append(adv_image.squeeze(0))

        return adv_images_list

    @attack_batch_with_label
    def PGD_Defined(self, image, label, steps=None, eps=8/255, alpha=2/255):
        if steps is None:
            steps = [1, 2, 3, 4, 5]

        image_ = image.clone().detach().to(self.device)
        adv_image = image_.clone().detach().to(self.device)
        adv_image = adv_image + torch.empty_like(adv_image).uniform_(-eps, eps)
        adv_image = torch.clamp(adv_image, 0, 1)

        adv_images_list = []

        for step in range(steps[-1]):
            adv_image.requires_grad = True

            cost = self.model.forward_loss(adv_image, copy.deepcopy(label))
            grad = torch.autograd.grad(cost, adv_image, create_graph=False, retain_graph=False)[0]

            adv_image = adv_image.detach() + grad.sign() * alpha
            delta = torch.clamp(adv_image - image_, min=-eps, max=eps)
            adv_image = torch.clamp(adv_image + delta, 0, 1)

            adv_images_list.append(adv_image.squeeze(0))

        return adv_images_list

    @attack_batch_with_label
    def CW_Targeted(self, image, label, steps=None, c=1, lr=0.02):

        if steps is None:
            steps = [2, 4, 6, 8, 10]

        images = image.clone().detach().to(self.device)

        target_labels = self.get_target_label(images, label)

        # Initialize w
        w = atanh(torch.clamp(images * 2 - 1, min=-1, max=1)).detach()
        w.requires_grad = True

        prev_cost = 1e10

        MSELoss = nn.MSELoss(reduction='none')
        Flatten = nn.Flatten()

        optimizer = optim.Adam([w], lr=lr)
        scaler = torch.cuda.amp.GradScaler()

        adv_images_list = []

        for step in range(steps[-1]):
            # Get adversarial images
            adv_images = tanh_space(w)

            # 半精度
            # with torch.cuda.amp.autocast():
            # Calculate loss
            current_L2 = MSELoss(Flatten(adv_images), Flatten(images)).sum(dim=1)
            L2_loss = current_L2.sum()
            f_loss = self.model.forward_loss(adv_images, copy.deepcopy(target_labels))
            cost = L2_loss + c * f_loss

            # optimizer.zero_grad()
            # cost.backward()
            # optimizer.step()
            scaler.scale(cost).backward()
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad()
            torch.cuda.empty_cache()

            if (step + 1) in steps:
                adv_images_list.append(adv_images.squeeze(0))

        return adv_images_list

    # CW(Default)
    @attack_batch_with_label
    def CW_Defined(self, image, label, steps=None, c=1, lr=0.02):

        if steps is None:
            steps = [2, 4, 6, 8, 10]

        images = image.clone().detach().to(self.device)

        # Initialize w
        w = atanh(torch.clamp(images * 2 - 1, min=-1, max=1)).detach()
        w.requires_grad = True

        prev_cost = 1e10

        MSELoss = nn.MSELoss(reduction='none')
        Flatten = nn.Flatten()

        optimizer = optim.Adam([w], lr=lr)
        scaler = torch.cuda.amp.GradScaler()

        adv_images_list = []

        for step in range(steps[-1]):
            # Get adversarial images
            adv_images = tanh_space(w)

            # with torch.cuda.amp.autocast():
                # Calculate loss
            current_L2 = MSELoss(Flatten(adv_images), Flatten(images)).sum(dim=1)
            L2_loss = current_L2.sum()
            f_loss = self.model.forward_loss(adv_images, copy.deepcopy(label))
            cost = L2_loss - c * f_loss

            # optimizer.zero_grad()
            # cost.backward()
            # optimizer.step()
            scaler.scale(cost).backward()
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad()
            torch.cuda.empty_cache()

            if (step + 1) in steps:
                adv_images_list.append(adv_images.squeeze(0))

        return adv_images_list

    # DDN(Targeted)
    @attack_batch_with_label_
    def DDN_Targeted(self, image, label, steps=10, init_epsilon: float = 2, gamma: float = 0.05):

        images = image.clone().detach().to(self.device)

        target_labels = self.get_target_label(images, label)
        max_stepsize = 1.0

        epsilon = init_epsilon * torch.ones_like(images)
        worst_norm = torch.abs(images).flatten().square().sum(axis=-1, keepdims=False).sqrt()

        best_l2 = worst_norm
        adv_found = torch.zeros_like(images).bool()
        adv_images = images.detach()

        for i in range(steps):
            adv_images.requires_grad = True
            # perform cosine annealing of LR starting from 1.0 to 0.01
            stepsize = (0.01 + (max_stepsize - 0.01) * (1 + torch.cos(torch.tensor(torch.pi * i / steps))) / 2)

            # Calculate loss
            # with torch.cuda.amp.autocast():
            cost = -self.model.forward_loss(adv_images, copy.deepcopy(target_labels))

            # Update adversarial images
            grad = torch.autograd.grad(cost, adv_images, retain_graph=False, create_graph=False)[0]
            grad = normalize_gradient_l2_norms(grad)

            delta = adv_images.detach() - images
            is_adversarial = torch.tensor(1, device=self.device).bool()

            l2 = delta.flatten().square().sum(axis=-1, keepdims=False).sqrt()
            is_smaller = l2 <= best_l2
            is_smaller.to(self.device)

            is_both = torch.logical_and(is_adversarial, is_smaller)
            adv_found = torch.logical_or(adv_found, is_adversarial)
            best_l2 = torch.where(is_both, l2, best_l2)

            # do step
            delta = delta.detach() + stepsize * grad

            epsilon = epsilon * torch.where(is_adversarial, 1.0 - gamma, 1.0 + gamma)
            epsilon = torch.minimum(epsilon, worst_norm)

            # project to epsilon ball
            delta *= atleast_kd(epsilon / (torch.sum(delta.flatten().square()).sqrt()), images.ndim)

            # clip to valid bounds
            adv_images = torch.clamp(images + delta, min=0, max=1).detach()

            # 清空显存
            torch.cuda.empty_cache()

        return adv_images.detach()

    # DDN(Default)
    @attack_batch_with_label_
    def DDN_Defined(self, image, label, steps=10, init_epsilon: float = 2, gamma: float = 0.05):

        images = image.clone().detach().to(self.device)
        max_stepsize = 1.0

        epsilon = init_epsilon * torch.ones_like(images)
        worst_norm = torch.abs(images).flatten().square().sum(axis=-1, keepdims=False).sqrt()

        best_l2 = worst_norm
        adv_found = torch.zeros_like(images).bool()
        adv_images = images.detach()

        for i in range(steps):
            adv_images.requires_grad = True
            # perform cosine annealing of LR starting from 1.0 to 0.01
            stepsize = (0.01 + (max_stepsize - 0.01) * (1 + torch.cos(torch.tensor(torch.pi * i / steps))) / 2)

            # Calculate loss
            # with torch.cuda.amp.autocast():
            cost = self.model.forward_loss(adv_images, copy.deepcopy(label))

            # Update adversarial images
            grad = torch.autograd.grad(cost, adv_images, retain_graph=False, create_graph=False)[0]
            grad = normalize_gradient_l2_norms(grad)

            delta = adv_images.detach() - images
            is_adversarial = torch.tensor(1, device=self.device).bool()

            l2 = delta.flatten().square().sum(axis=-1, keepdims=False).sqrt()
            is_smaller = l2 <= best_l2
            is_smaller.to(self.device)

            is_both = torch.logical_and(is_adversarial, is_smaller)
            adv_found = torch.logical_or(adv_found, is_adversarial)
            best_l2 = torch.where(is_both, l2, best_l2)

            # do step
            delta = delta + stepsize * grad

            epsilon = epsilon * torch.where(is_adversarial, 1.0 - gamma, 1.0 + gamma)
            epsilon = torch.minimum(epsilon, worst_norm)

            # project to epsilon ball
            delta *= atleast_kd(epsilon / (torch.sum(delta.detach().flatten().square()).sqrt()), images.ndim)

            # clip to valid bounds
            adv_images = torch.clamp(images + delta, min=0, max=1).detach()

            # 清空显存
            torch.cuda.empty_cache()

        return adv_images

    ################################### 增加方法 ###########################################3
    @attack_batch_with_label_
    def ERFGSM_Targeted(self, image, label, steps=None,  eps=8 / 255, alpha=2 / 255):
        if steps is None: # 默认步数
            steps = [2, 4, 6, 8, 10]
            
        images = image.clone().detach().to(self.device)
        edges = kornia.filters.canny(images, 0.1, 0.3)[0]
        h, w, c = images.shape
        noise = np.random.normal(0, 50, (h, w, c))
        noise = noise.astype(np.uint8) # 正态分布噪声
        noise = torch.from_numpy(noise).to(self.device)
        
        target_labels = self.get_target_label(images, label)

        # 分离计算图 x0'
        adv_images = images.clone().detach()
        # x0'
        adv_images = adv_images + edges*alpha*noise.sign()

        adv_images.requires_grad = True

        adv_images_list = []
        for step in range(steps[-1]):

            # Calculate loss
            cost = -self.model.forward_loss(adv_images, copy.deepcopy(target_labels))
            # Update adversarial images
            grad = torch.autograd.grad(cost, adv_images, retain_graph=False, create_graph=False)[0]
            
            edges = kornia.filters.canny(adv_images, 0.1, 0.3)[0]

            adv_images = adv_images.detach() + edges * (eps-alpha) * grad.sign()

            if (step + 1) in steps:
                adv_images_list.append(adv_images.squeeze(0))

        return adv_images_list
    
    @attack_batch_with_label_
    def ERFGSM_Defined(self, image, label, steps=None,  eps=8 / 255, alpha=2 / 255):
        if steps is None: # 默认步数
            steps = [2, 4, 6, 8, 10]
            
        images = image.clone().detach().to(self.device)
        edges = kornia.filters.canny(images, 0.1, 0.3)[0]
        h, w, c = images.shape 
        noise = np.random.normal(0, 50, (h, w, c))
        noise = noise.astype(np.uint8)  # 正态分布噪声
        noise = torch.from_numpy(noise).to(self.device)

        # 分离计算图 x0'
        adv_images = images.clone().detach()
        # x0'
        adv_images = adv_images + edges*alpha*noise.sign()

        adv_images.requires_grad = True

        adv_images_list = []
        for step in range(steps[-1]):
            adv_images.requires_grad = True

            # Calculate loss  无targeted_labels
            cost = -self.model.forward_loss(adv_images, copy.deepcopy(label))
            # Update adversarial images
            grad = torch.autograd.grad(cost, adv_images, retain_graph=False, create_graph=False)[0]
            
            edges = kornia.filters.canny(adv_images, 0.1, 0.3)[0]

            adv_images = adv_images.detach() + edges* (eps-alpha) * grad.sign()

            if (step + 1) in steps:
                adv_images_list.append(adv_images.squeeze(0))

        return adv_images_list

class All_Attack(White_Box_Attack, Noise_Attack, Blur_Attack, Color_Attack, Geometric_Attack):
    def __init__(self, model=None, device=None, model_type='classification', **kwargs):
        # 只调用第一个父类的构造函数
        super(All_Attack, self).__init__(model=model, device=device, model_type=model_type, **kwargs)




