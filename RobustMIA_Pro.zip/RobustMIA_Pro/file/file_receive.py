import os
import shutil


class FileReceive:
    @staticmethod
    def save_dir(resource_path, save_path, is_model=False) -> (bool, str):
        model_name = None
        if is_model:
            file_names = os.listdir(resource_path)
            for file_name in file_names:
                ends = ('.pt', '.pth', '.pkl')
                if any(file_name.endswith(end) for end in ends):
                    model_name = file_name
        if os.path.exists(save_path):
            shutil.rmtree(save_path)

        shutil.copytree(resource_path, save_path)
        return True, model_name

