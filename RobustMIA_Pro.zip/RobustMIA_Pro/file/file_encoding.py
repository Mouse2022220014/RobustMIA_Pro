from PIL import Image, ImageDraw, ImageFont
import base64
import torch
from torchvision.transforms.functional import to_pil_image
from io import BytesIO
import colorsys
import random


font = ImageFont.truetype('msyh.ttc', 15)


def pil_to_base64(img: Image):
    output_buffer = BytesIO()
    img.save(output_buffer, format='JPEG', quality=60)
    byte_data = output_buffer.getvalue()
    base64_str = base64.b64encode(byte_data).decode()
    return base64_str


class FileEncode:
    def __init__(self):
        pass

    @classmethod
    def get_rgb_color(num: int):
        rgb_list = []
        for i in range(num):
            color = colorsys.hsv_to_rgb(i / num, (80 + 10 * random.random()) / 100, (50 + 10 * random.random()) / 100)
            rgb_list.append(color)
        return rgb_list

    @classmethod
    def classify_image_encode(cls, image_: torch.Tensor, label_: list, pred_: list):
        label_ = label_[0]
        pred_ = pred_[0]

        background = Image.new('RGB', (224, 240), (0, 0, 0))
        image = to_pil_image(image_).resize((224, 206)).convert('RGB')
        # 给图片加上标签
        draw = ImageDraw.Draw(background)
        draw.text((0, 206), 'label:{}'.format(label_), font=font, fill=(255, 255, 255))
        draw.text((0, 223), 'pred:{}'.format(pred_), font=font, fill=(255, 255, 255))
        background.paste(image, (0, 0))
        # 将图片转换为base64编码
        base64_str = pil_to_base64(background)
        return base64_str

    @classmethod
    def segmentation_image_encode(cls, image_: torch.Tensor, label_: torch.Tensor, pred_: torch.Tensor):
        # 把label和pred作为下标转换为mask
        label_, pred_ = label_.int(), pred_.int()
        rgb_list = torch.tensor(FileEncode.get_rgb_color(int(max(label_.max() - 1, pred_.max()))))

        # 对label_和pred_进行伪色彩处理
        label_mask = torch.zeros(image_.shape, dtype=torch.float32).to('cpu')
        pred_mask = torch.zeros(image_.shape, dtype=torch.float32).to('cpu')

        image_ = image_.to('cpu')

        for i, rgb in enumerate(rgb_list):
            label_mask[:, label_ == (i + 1)] = rgb[:, None]
            pred_mask[:, pred_ == (i + 1)] = rgb[:, None]

        label_pil = image_.where(label_mask <= 1e-6, label_mask * 0.5 + image_ * 0.5)
        pred_pil = image_.where(pred_mask <= 1e-6, pred_mask * 0.5 + image_ * 0.5)

        background = Image.new('RGB', (448, 224), (0, 0, 0))
        label_pil = to_pil_image(label_pil).resize((224, 224))
        pred_pil = to_pil_image(pred_pil).resize((224, 224))
        background.paste(label_pil, (0, 0))
        background.paste(pred_pil, (224, 0))

        # 将图片转换为base64编码
        base64_str = pil_to_base64(background)
        return base64_str

