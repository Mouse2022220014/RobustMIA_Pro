window.onload = function () {
// 获取所有的二级标题
    var headings = document.getElementsByTagName('h2');
    // 创建目录
    var ul = document.createElement('ul');
    for (let i = 0; i < headings.length; i++) {
        const heading = headings[i];
        const li = document.createElement('li');
        let a = document.createElement('a');
        a.href = '#' + heading.id;
        // 去掉标题中的中文数字和括号内的内容
        // Num_reg = /[一二三四五六七八九十、]+/;
        Num_reg = ['一、','二、','三、','四、','五、','六、','七、','八、','九、','十、'];
        a.textContent = heading.innerText.replace(/\(.*\)/, '').replace(/[:：]/, '').replace(Num_reg[i], '');
        li.appendChild(a);
        // 如果该标题下有子标题，则创建子目录
        let next_item = heading.nextElementSibling;
        const subUl = document.createElement('ul');
        while (next_item) {
            const subLi = document.createElement('li');
            if (next_item.tagName === 'DIV') {
                const subHeading = next_item.getElementsByTagName('h3')[0];
                const subA = document.createElement('a');
                subA.href = '#' + subHeading.id;
                // 去掉标题中的阿拉伯数字、分号和括号内的内容
                subA.textContent = subHeading.innerText.replace(/\(.*\)/, '').replace(/[:：]/, '').replace(/^[1-9][0-9]*[、]/, '');
                subLi.appendChild(subA);
                subUl.appendChild(subLi);
            }else {
                break;
            }
            next_item = next_item.nextElementSibling;
        }
        li.appendChild(subUl);
        ul.appendChild(li);
    }

    // 将目录添加到页面上
    document.getElementById('toc').appendChild(ul);
    // 给目录添加点击事件
    const lis = document.querySelectorAll('#toc > ul > li');
    for (let i = 0; i < lis.length; i++) {
        lis[i].addEventListener('click', function () {
            for (let j = 0; j < lis.length; j++) {
                if (j !== i) {
                    lis[j].classList.remove('active');
                }
            }
            this.classList.toggle('active');
        });
    }
    //平滑滚动
    a = document.querySelectorAll('#toc a');

    a.forEach(function (link) {
        link.addEventListener('click', function (e) {
            e.preventDefault();

            var targetId = this.getAttribute("href").substring(1);
            var targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({behavior: 'smooth'});
            }
        })
    })

    // 获取搜索框和目录中所有一级标题和二级标题
    const searchInput = document.getElementById('search');
    const allHeadings = document.querySelectorAll('#toc>ul>li>a');
    const allh1 = document.querySelectorAll('#toc>ul>li');
    // 给搜索框添加输入事件
    searchInput.addEventListener('input', function () {
        // 收起目录的所有子目录
        allh1.forEach(function (item) {
            item.classList.remove('active');
        });
        const searchText = this.value.toLowerCase();
        // 遍历所有标题，查找匹配的标题
        for (let i = 0; i < allHeadings.length; i++) {
            const heading = allHeadings[i];
            const headingText = heading.textContent.toLowerCase();
            if (headingText.indexOf(searchText) !== -1) {
                heading.style.display = 'block';
            } else {
                // 如果标题不匹配，则查找标题下的子标题
                const subHeadings = heading.nextElementSibling.querySelectorAll('li>a');
                let isShow = false;
                for (let j = 0; j < subHeadings.length; j++) {
                    const subHeading = subHeadings[j];
                    const subHeadingText = subHeading.textContent.toLowerCase();
                    if (subHeadingText.indexOf(searchText) !== -1) {
                        isShow = true;
                        break;
                    }
                }
                // 如果子标题中有匹配的，则显示该标题，否则隐藏该标题
                if (isShow) {
                    heading.style.display = 'block';
                    // 展开该标题的子目录
                    heading.parentNode.classList.add('active');
                } else {
                    heading.style.display = 'none';
                }
            }
        }
    });
    var image_explanation = document.getElementsByClassName("image_explanation");
    for (let i = 0; i < image_explanation.length; i++){
        let text = image_explanation[i].innerText;
        number = text.match(/\d+/g);
        text = text.replace(number[0],i+1+"")
        image_explanation[i].innerText = text;
    }
};




// 页面不在顶部时向下滚动header向上隐藏，向上滚动header向下显示
let lastScrollTop = 0;
window.addEventListener('scroll', function () {
    let left_div = document.querySelector('#left_div');
    const header = document.querySelector('header');
    let scrollTop = window.scrollY || document.documentElement.scrollTop;
    // 页面轮向下滚动时，header向上隐藏
    if (scrollTop > lastScrollTop) {
        header.style.top = '-75px';
        header.style.transition = 'top 0.8s';
        // header隐藏时,left_div向上移动
        left_div.style.top = '25px';
        left_div.style.transition = 'top 0.8s';
        // header隐藏时，鼠标移到屏幕顶部时显示header
        header.addEventListener('mouseover', function () {
            header.style.top = '5%';
            header.style.transition = 'top 0.8s';
            // header显示时，left_div向下移动
            left_div.style.top = '20%';
            left_div.style.transition = 'top 0.8s';
        });
    } else {
        // header向下显示
        header.style.top = '5%';
        header.style.transition = 'top 0.8s';
        // header显示时，left_div向下移动
        left_div.style.top = '20%';
        left_div.style.transition = 'top 0.8s';
    }
    lastScrollTop = scrollTop;
});