import gc
import importlib.util
import torch


def find_best_device():
    gpu_memory = []
    if not torch.cuda.is_available():
        print("cude is not available, use cpu")
        return torch.device('cpu')
    try:
        import pynvml
        pynvml.nvmlInit()
        device_count = pynvml.nvmlDeviceGetCount()
        for i in range(device_count):
            handle = pynvml.nvmlDeviceGetHandleByIndex(i)
            info = pynvml.nvmlDeviceGetMemoryInfo(handle)
            gpu_memory.append(info.free)
        best_cuda_device = max(gpu_memory)
        print("use best gpu: ", gpu_memory.index(best_cuda_device), "memory: ", best_cuda_device / 1024 / 1024 / 1024, "GB")
        pynvml.nvmlShutdown()
        return torch.device(f'cuda:{gpu_memory.index(best_cuda_device)}')
    except ImportError:
        print("pynvml library is not found. Please install it to get GPU memory information.")


class ModelHandler:
    def __init__(self,model_runner_file_path, model_path, device, model_type):
        self.model_runner_file_path = model_runner_file_path
        self.model_path = model_path
        self.model_type = model_type
        self.device = device
        self.model_runner = self._load_model_runner()

    def _load_model_runner(self):
        spec = importlib.util.spec_from_file_location("model_runner", self.model_runner_file_path)
        model_runner_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(model_runner_module)

        ModelRunner = getattr(model_runner_module, "ModelRunner")

        return ModelRunner(self.model_path, self.device)

    def forward_pred(self,img):
        with torch.no_grad():
            pred = self.model_runner.run_impl(img)
        gc.collect()
        torch.cuda.empty_cache()
        return pred

    def forward_loss(self, img, label):
        loss = self.model_runner.calc_loss_impl(img, label)
        gc.collect()
        torch.cuda.empty_cache()
        return loss
