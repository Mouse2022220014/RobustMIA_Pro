import gc
import shutil
import sys
import torchvision
import torch
import torch.utils.data

# 我的模块
from Data_set.voc_detection import *
from image_process import *

from Model_prediction.run_model import ModelHandler, find_best_device
from Model_prediction.get_map import calculate_map


# 获取所有标签
def get_all_labels(data):
    all_label = []
    for _, _, label in data:
        all_label += label
    all_label = list(set(all_label))
    if 'background' in all_label:
        all_label.remove('background')
    if len(all_label) == 1:
        raise Exception('只有一个类别，无法构建目标攻击')
    return all_label


# 检测模型预测
class Detection_prediction:
    # 加载模型
    def __init__(self, id_):
        self.device = find_best_device()
        self.path = './detection/'
        self.data_list = []
        # 加载打包好的模型pt，pth，pkl模型
        if os.path.exists(self.path + 'model/model.pt'):
            self.model_path = self.path + 'model/model.pt'
        elif os.path.exists(self.path + 'model/model.pth'):
            self.model_path = self.path + 'model/model.pth'
        elif os.path.exists(self.path + 'model/model.pkl'):
            self.model_path = self.path + 'model/model.pkl'
        else:
            print("not found model file in " + self.path)

        self.model_handler = ModelHandler(self.path + 'model/process.py', self.model_path, self.device, "detection")
        self.data = Voc_detection(self.path + 'data/', self.model_handler)
        self.data_len = len(self.data)
        self.all_labels = get_all_labels(self.data)
        self.numclasses = len(self.all_labels)
        self.max_p, self.predicts = self.get_max_map()
        self.attack = All_Attack(self.model_handler, self.device, "detection", all_labels=self.all_labels)

    def __del__(self):
        # 清除缓存文件夹
        if os.path.exists(self.path):
            shutil.rmtree(self.path)
        del self.data
        del self.data_list
        # 在Linux环境下，强制回收内存
        if sys.platform in ("linux", "linux2"):
            import ctypes
            libc = ctypes.CDLL("libc.so.6")
            libc.malloc_trim(0)

    # def get_image(self, image_save, predict_save, label_save, index_save):
    #     images = []
    #     images.append(
    #         file_encoding.Encoding_file.detect_image_encode(self.data[index_save][0], self.data[index_save][1],
    #                                                         self.data[index_save][2], self.predicts[index_save]['boxes'],
    #                                                         self.predicts[index_save]['labels'], self.all_labels))
    #     for j in range(len(image_save)):
    #         images.append(
    #             file_encoding.Encoding_file.detect_image_encode(image_save[j], label_save[0][j], label_save[1][j], predict_save[0][j],
    #                                                             predict_save[1][j], self.all_labels))
    #     return images

    def predict(self, method, parameter, *args, **kwargs):
        preds_list = []
        labels_list_ = []
        predict_save, image_save, label_save = None, None, None
        index_save = random.randint(0, len(self.data) - 1)
        for i, (image, boxes, classes) in enumerate(self.data):
            if method in ["Rotation", "Translation", "Rescale", "Distortion"]:
                _, h, w = image.shape
                box_process = Geometric_box()
                boxes_list = getattr(box_process, method)(h, w, boxes, parameter[tuple(parameter.keys())[0]])
                classes_list = [classes] * len(boxes_list)
            else:
                boxes_list = [boxes] * len(parameter[tuple(parameter.keys())[0]])
                classes_list = [classes] * len(parameter[tuple(parameter.keys())[0]])

            images = getattr(self.attack, method)(image, [{'boxes': boxes, 'labels': classes}], parameter[tuple(parameter.keys())[0]])
            # preds = []
            # for j in range(len(images)):
            #     preds += self.model_handler.forward_pred(images)
            preds = self.model_handler.forward_pred(images)
            labels_list_.append([boxes_list, classes_list])
            preds_list.append(preds)

            if i == index_save:
                predict_save = [[preds[j]['boxes'] for j in range(len(preds))], [preds[j]['labels'] for j in range(len(preds))]]
                image_save = images
                label_save = [boxes_list, classes_list]

            torch.cuda.empty_cache()

        # 转置
        preds_list = [i for i in zip(*preds_list)]
        labels_list = []
        for i in range(len(labels_list_[0][0])):
            labels_list.append([])
            for j in range(len(labels_list_)):
                labels_list[i].append({'boxes': labels_list_[j][0][i], 'labels': labels_list_[j][1][i]})

        mAP_list = []
        for i in range(len(preds_list)):
            preds = preds_list[i]
            labels = labels_list[i]
            mAP_list.append(calculate_map(preds, labels))

        return mAP_list, predict_save, image_save, label_save

    def get_max_map(self):
        preds_list = []
        labels_list = []
        for image, boxes, classes in self.data:
            image = image.to(self.device)
            with torch.no_grad():
                preds = self.model_handler.forward_pred(image.unsqueeze(0))
            preds_list += preds
            labels_list.append({'boxes': boxes, 'labels': classes})
        map = calculate_map(preds_list, labels_list)
        print("模型mAP为" + str(map))
        if map == 0:
            print("模型的mAP为0，已终止测试，请检查模型是否正确")
        elif map < 0.5:
            print("当前模型的mAP为"+str(map)+"，小于50%，已终止测试，请检查模型是否正确")
        return map, preds_list