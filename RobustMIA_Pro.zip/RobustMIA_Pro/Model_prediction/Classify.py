import torch.utils.data
from PyQt5.QtCore import pyqtSignal
import base64
import io


# 我的模块
from Data_set.imageloader_classify import ImageLoader_classify
from Model_prediction.run_model import *
from image_process import *
from file.file_encoding import FileEncode


def get_all_labels(data):
    all_label = []
    for i in range(len(data)):
        if data[i][1][0] not in all_label:
            all_label.append(data[i][1][0])
            print(all_label)
    return all_label


class Classify_prediction:
    def __init__(self, session):
        self.session = session
        self.path = './classification/'

        if os.path.exists(self.path + 'model/model.pt'):
            self.model_path = self.path + 'model/model.pt'
        elif os.path.exists(self.path + 'model/model.pth'):
            self.model_path = self.path + 'model/model.pth'
        elif os.path.exists(self.path + 'model/model.pkl'):
            self.model_path = self.path + 'model/model.pkl'
        else:
            pass

        self.data_path = self.path + 'data'

        self.data = ImageLoader_classify(self.data_path)
        self.data_len = len(self.data)
        self.all_labels = get_all_labels(self.data)

        self.device = find_best_device()

        self.model_handler = ModelHandler(self.path + 'model/' + 'process.py', self.model_path, self.device,
                                          session['model_type'])
        # 原图准确率
        self.max_p, self.predicts = self.get_max_accuracy()

        self.attack = All_Attack(self.model_handler, self.device, session['model_type'], all_labels=self.all_labels)

    def get_max_accuracy(self) -> (float, list):
        # 原始数据的正确率
        totality = 0
        correct = 0
        predicts = []

        for image, label in self.data:
            pred = self.model_handler.forward_pred(image.unsqueeze(0).to(self.device))

            predicts.append(pred)
            if pred[0] == label[0]:
                correct += 1
            totality += 1

        print('模型准确率为' + str(correct/totality * 100) + '%')

        return correct/totality * 100, predicts

    def predict(self, method, parameter):
        # 预测攻击后的图像
        # rw_list得分列表
        rw_list = torch.tensor([], dtype=torch.int16)
        predict_save, images_save, label_save = None, None, None
        index_save = random.randint(0, self.data_len-1)

        for i, (image, label) in enumerate(self.data):
            # rw:每张图像的得分
            rw = torch.tensor([], dtype=torch.int16)
            images = getattr(self.attack, method)(image, label, parameter[tuple(parameter.keys())[0]])
            images = images.to(self.device)

            predicts = self.model_handler.forward_pred(images)

            if i == index_save:
                predict_save = predicts
                images_save = images
                label_save = label

            for pred in predicts:
                if pred == label[0]:
                    rw = torch.cat((rw, torch.tensor([1], dtype=torch.int16)))
                else:
                    rw = torch.cat((rw, torch.tensor([0], dtype=torch.int16)))
            rw_list = torch.cat((rw_list, rw.unsqueeze(0)))
        # 转置以得到不同强度下的得分(原本是不同图像下的得分)
        item_T = rw_list.permute(1, 0)
        # p_list 同种攻击方式下不同强度的准确率
        p_list = []
        for item in item_T:
            p_list.append(100*torch.sum(item)/len(item))
        # print("不同强度下正确率:", p_list)
        return p_list, predict_save, images_save, label_save, index_save

    def get_images(self, image_save, label_save, pred_save, index_save):
        # 示例图像打印标签和预测结果并保存,11张
        images = []
        # 获取原图
        images.append(FileEncode.classify_image_encode(self.data[index_save][0], label_save, self.predicts[index_save]))
        # 获取攻击图像
        for i in range(len(image_save)):
            images.append(FileEncode.classify_image_encode(image_save[i], label_save, pred_save[i]))

        # image_data = base64.b64decode(images[0])
        # image_buffer = io.BytesIO(image_data)
        # image = Image.open(image_buffer)
        # image.show()

        return images


if __name__ == '__main__':
    session = {'username': 'wzk', 'model_name': 'model', 'model_type': 'classification'}
    c = Classify_prediction(session)
    parameter_ = {"Motion_Blur": [5, 11, 15, 21, 25, 31, 35, 41, 45, 51]}
    c.predict('Motion_Blur', parameter_)
