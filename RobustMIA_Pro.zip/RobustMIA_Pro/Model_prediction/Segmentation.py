import torch.utils.data

# 我的模块
from Data_set.image_segmentation import Image_segmentation
from image_process import *
from Model_prediction.run_model import *
from file.file_encoding import FileEncode


def dice_coefficient(y_true, y_pred, smooth=0.00001, class_nums=2):
    y_true = torch.nn.functional.one_hot(y_true.squeeze(0), class_nums)
    # 类别，h，w
    y_true = y_true.permute(2, 0, 1)
    # 去掉背景
    y_true = y_true[1:]
    y_pred = y_pred[1:]
    pred_flat = y_pred.reshape(class_nums - 1, -1).to('cpu')
    gt_flat = y_true.reshape(class_nums - 1, -1).to('cpu')

    tp = torch.sum(gt_flat * pred_flat, dim=1)
    fp = torch.sum(pred_flat, dim=1) - tp
    fn = torch.sum(gt_flat, dim=1) - tp
    score = (2 * tp + smooth) / (2 * tp + fp + fn + smooth)
    return (score.sum() / (class_nums - 1)).to(torch.float16)


class Segmentation_prediction:
    def __init__(self, session):
        self.session = session
        self.device = find_best_device()
        self.path = './segmentation/'

        self.data = Image_segmentation(self.path + 'data')
        self.model_handler = ModelHandler(self.path + 'model/' + 'process.py',
                                          self.path + 'model/' + self.session['model_name'],
                                          self.device, self.session['model_type'])
        self.max_p, self.predicts = self.get_max_dice()
        self.attack = All_Attack(self.model_handler, self.device, self.session['model_type'])

    def get_max_dice(self):
        totality = 0
        dice_sum = 0
        predicts = []
        for image, label in self.data:
            with torch.no_grad():
                preds = self.model_handler.forward_pred(image.unsqueeze(0))
            predicts.append(preds.squeeze(0))
            class_nums = preds.shape[1]  # 获取类别数
            totality += 1
            dice_sum += dice_coefficient(label.long(), preds.squeeze(0), class_nums=class_nums)
        dice_sum = float(dice_sum)
        print("模型Dice为" + str(dice_sum / totality * 100) + "%")
        if dice_sum == 0:
            raise Exception("模型Dice为0，已终止测试，请检查模型是否正确")
        elif dice_sum / totality < 0.8:
            raise Exception("当前模型Dice为"+str(dice_sum / totality*100)+"%，小于80%，已终止测试，请检查模型是否正确")
        return dice_sum / totality, predicts

    def predict(self, method, parameter, *args, **kwargs):
        dices_list = torch.tensor([], dtype=torch.float16).to(self.device)
        predict_save, image_save, label_save = None, None, None
        index_save = random.randint(0, len(self.data) - 1)
        for i, (image, label) in enumerate(self.data):
            dices = torch.tensor([], dtype=torch.float16).to(self.device)

            if method in ["Rotation", "Translation", "Rescale", "Distortion"]:
                label = label.float()
                label = getattr(self.attack, method)(label, label, parameter[tuple(parameter.keys())[0]], 'nearest')
                label = label.long()
            images = getattr(self.attack, method)(image, label.unsqueeze(0), parameter[tuple(parameter.keys())[0]])
            predicts = self.model_handler.forward_pred(images)

            class_nums = predicts.shape[1]  # 获取类别数
            if method in ["Rotation", "Translation", "Rescale", "Distortion"]:
                for j in range(len(predicts)):  # 遍历第一维度
                    dice_ = dice_coefficient(label[j].long().to(self.device), predicts[j], class_nums=class_nums).to(
                        self.device)
                    dices = torch.cat([dices, dice_.unsqueeze(0)])  # 每个批次的dice
            else:
                for j in range(len(predicts)):
                    dice_ = dice_coefficient(label.long().to(self.device), predicts[j], class_nums=class_nums).to(
                        self.device)
                    dices = torch.cat([dices, dice_.unsqueeze(0)])

            if i == index_save:
                predict_save = predicts
                image_save = images
                label_save = label

            dices_list = torch.cat((dices_list, dices.unsqueeze(0)))  # 全部测试集的所有dice
        item_T = dices_list.permute(1, 0)  # 转置
        dice_list = []
        for item in item_T:
            dice_list.append(float(item.mean().item()))

        predict_save = [torch.argmax(predict_save[i], dim=0) for i in range(len(predict_save))]
        return dice_list,predict_save,image_save, label_save

    def get_image(self, image_save, label_save, pred_save, index_save):
        images = []
        # 原图
        images.append(FileEncode.segmentation_image_encode(self.data[index_save][0], label_save,
                                                           self.predicts[index_save]))

        for i in range(len(image_save)):
            images.append(FileEncode.segmentation_image_encode(image_save[i], label_save, pred_save[i]))

        return images



