from PyQt5.QtCore import pyqtSlot, Qt, QPoint
from PyQt5.QtGui import QFont, QEnterEvent, QPixmap, QColor, QPainterPath, QPainter
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QDialog, QVBoxLayout, QPushButton, QHBoxLayout, QLabel
from PyQt5 import QtCore, QtWidgets


class CustomTitleBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        # 内容初始化
        layout = QHBoxLayout(self)
        self.label_title = QLabel("测试结果")
        self.minimize_button = QPushButton("Minimize")
        self.maximize_button = QPushButton("Maximize")
        self.close_button = QPushButton("Close")

        self.label_title.setObjectName("label_title")
        self.minimize_button.setObjectName("minimize_button")
        self.maximize_button.setObjectName("maximize_button")
        self.close_button.setObjectName("close_button")

        layout.addWidget(self.label_title)
        layout.addStretch(1)
        layout.addWidget(self.minimize_button)
        layout.addWidget(self.maximize_button)
        layout.addWidget(self.close_button)

        # 主窗口初始化设置
        self._init_main_window()

        # 设置 3 个按钮的图标字体
        self._close_max_min_icon()
        self.close_button.clicked.connect(self.on_close_button_clicked)

        # 添加用于跟踪鼠标拖动的变量
        self.startMousePos = None
        self.startWindowPos = None

        # 设置QSS
        # 设置标题栏的背景颜色
        self.setStyleSheet("""
                    CustomTitleBar {
                        background: transparent;
                    }
                """)

    def _init_main_window(self):
        # 设置窗体无边框
        self.setWindowFlags(Qt.FramelessWindowHint)
        # 设置背景透明
        self.setAttribute(Qt.WA_TranslucentBackground)

    def _close_max_min_icon(self):
        self.maximize_button.setFont(QFont("Webdings"))
        self.minimize_button.setFont(QFont("Webdings"))
        self.close_button.setFont(QFont("Webdings"))
        self.maximize_button.setText('1')
        self.minimize_button.setText('0')
        self.close_button.setText('r')

    @pyqtSlot()
    def on_close_button_clicked(self):
        self.parent().close()

    def mousePressEvent(self, event):
        # 当鼠标按下时，记录鼠标的位置和窗口的位置
        self.startMousePos = event.globalPos()
        self.startWindowPos = self.window().frameGeometry().topLeft()

    def mouseMoveEvent(self, event):
        # 当鼠标移动时，如果鼠标按下的位置已经记录，那么移动窗口
        if self.startMousePos is not None:
            movePos = event.globalPos() - self.startMousePos
            self.window().move(self.startWindowPos + movePos)

    def mouseReleaseEvent(self, event):
        # 当鼠标释放时，清除记录的鼠标按下的位置
        self.startMousePos = None

