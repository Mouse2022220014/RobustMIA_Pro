from PyQt5.QtCore import QThread, pyqtSignal
from Robustness_test.Classify_test import ClassifyTest
from Robustness_test.detection_test import DetectionTest
from Robustness_test.segmentation_test import SegmentationTest
import socket
import json
import zipfile
import os
import shutil
import time


def compress_folder(folder_path: str, output_path: str):
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, folder_path))



class TestThread_socket(QThread):
    finish = pyqtSignal(dict)
    progress_emit = pyqtSignal(int)

    def __init__(self, session):
        super().__init__()
        self.session = session
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def run(self):
        # 稳定性测试Classify_test <- 原始、攻击图像预测结果Classify_prediction <- 拿到原始数据ImageLoader_classify,
        #                                                                   模型预测方法 Model_handler
        #                                                                   图像攻击方法 Attack
        try:
            # 尝试连接到设备
            print('connecting...', self.session['server_ip'])
            self.client_socket.connect((self.session['server_ip'], 5000))
            print("成功连接到设备")

        except Exception as e:
            print("连接时出现错误:", e)
            # 然后返回(待填写)

        messages = ['receive_session', 'receive_data_file', 'receive_model_file', 'start_testing']
        # 发送消息
        for message in iter(messages):
            print('发送', message)
            self.client_socket.send(str.encode(message))
            self.wait_callback()

        self.client_socket.close()

        self.finish.emit(self.session)

    def wait_callback(self):
        # 等待服务器发送信号
        callback = self.client_socket.recv(1024).decode()
        print('收到信号', callback)
        func = getattr(self, callback)
        func()

    # 发送model
    def send_model(self):
        # 压缩文件
        model_path = self.session['model_type'] + '/model'
        compress_folder(model_path, model_path + '.zip')

        with open(model_path + '.zip', 'rb') as f:
            while True:
                data = f.read(20480)
                if not data:
                    self.client_socket.sendall(b"END")
                    break
                self.client_socket.sendall(data)

        # 删除临时压缩包
        os.remove(model_path + '.zip')
        print(self.client_socket.recv(1024).decode())

    # 发送data
    def send_data(self):
        # 压缩文件
        data_path = self.session['model_type'] + '/data'

        compress_folder(data_path, data_path + '.zip')

        # 发送文件
        with open(data_path + '.zip', 'rb') as f:
            while True:
                data = f.read(20480)
                if not data:
                    self.client_socket.sendall(b"END")
                    break
                self.client_socket.sendall(data)

        # 删除临时压缩包
        os.remove(data_path + '.zip')
        print(self.client_socket.recv(1024).decode())

    # 发送session
    def send_session(self):
        self.client_socket.send(json.dumps(self.session).encode())

    def progress_(self):
        while True:
            test_index = self.client_socket.recv(1024).decode()
            if test_index == 'END':
                break

            test_index = int(test_index)
            self.progress_emit.emit(test_index)

        self.client_socket.send(str.encode("finished"))
        # 结束后接收session数据
        data = b""
        while True:
            chunk = self.client_socket.recv(8192)
            data += chunk

            if data.endswith(b"END"):
                data = data[:-len(b"END")]
                break

        self.session = json.loads(data.decode())

        print(self.session['score_sum'])
        self.finish.emit(self.session)


class TestThread(QThread):
    finish = pyqtSignal(dict)
    progress_emit = pyqtSignal(int)

    def __init__(self, session):
        super().__init__()
        self.session = session
        if self.session['model_type'] == 'classification':
            self.test = ClassifyTest(self.session)
        elif self.session['model_type'] == 'segmentation':
            self.test = SegmentationTest(self.session)
        elif self.session['model_type'] == 'detection':
            self.test = DetectionTest(self.session)

        self.test.progressSignal.progress.connect(self.progress_)

    def run(self):
        point_line_data, radar_data, score_sum, images_list = self.test.full_proces_testing()
        # 存储数据
        self.session['point_line_data'] = point_line_data
        self.session['radar_data'] = radar_data
        self.session['score_sum'] = score_sum
        self.session['images_list'] = images_list   # [[11], [11], [11], ... ] 36组

        # 发送数据
        self.finish.emit(self.session)
        shutil.rmtree(self.session['model_type'] + '/data')
        shutil.rmtree(self.session['model_type'] + '/model')

    def progress_(self, testing_index):
        self.progress_emit.emit(testing_index)


class LoadingThread(QThread):
    loading_signal = pyqtSignal(str)
    is_running = False
    def run(self):
        while self.is_running:
            self.loading_signal.emit("数据正在加载中 ")
            time.sleep(0.5)
            self.loading_signal.emit("数据正在加载中.")
            time.sleep(0.5)
            self.loading_signal.emit("数据正在加载中..")
            time.sleep(0.5)
            self.loading_signal.emit("数据正在加载中...")
            time.sleep(0.5)
