from PyQt5.QtWidgets import QApplication, QGraphicsView, QGraphicsItem, QGraphicsScene, QGraphicsLineItem
from PyQt5.QtGui import QPainter, QTransform, QFont, QPainterPath, QColor, QPen, QBrush
from PyQt5.QtCore import QRectF, Qt, QPointF
import sys

class LineGraphItem(QGraphicsItem):
    def __init__(self, point_line_data):
        super().__init__()
        self.data = point_line_data
        self.length = 400
        self.height = 250
    def boundingRect(self):
        return QRectF(0, 0, self.length, self.height)

    def paint(self, painter, option, widget):
        # 启用抗锯齿
        painter.setRenderHint(QPainter.Antialiasing)

        # 创建一个 QPen 对象用于绘制矩形框
        pen = QPen()
        pen.setWidth(2)
        color = QColor(217, 217, 217) # 白色
        pen.setColor(color)
        painter.setPen(pen)

        # 绘制矩形框
        painter.drawLine(0, 0, 0, 250)  # 左边
        painter.drawLine(0, 250, 500, 250) # 下边

        # 绘制刻度
        self.paint_scale(painter)
        # 绘制折线
        self.paint_point(painter)
        # 绘制标红区域
        self.paint_red_color(painter)

    def paint_scale(self, painter):
        for i in range(0, 11, 2):
            x = i * 50
            painter.setPen(QColor("white"))
            painter.drawLine(x, 250, x, 260) # 下边小刻度线
            painter.setPen(QColor('white'))
            painter.drawText(x - 5, 275, str(i))  # 刻度标签
            if i != 0:
                painter.setPen(QColor(250, 250, 250, 100))
                painter.drawLine(x, 250, x, 0)
                painter.setPen(QColor("white"))
        for i in range(0, 6):
            y = 250 - i * 50
            painter.setPen(QColor("white"))
            painter.drawLine(0, y, -10, y)  # 刻度线
            painter.setPen(QColor('white'))
            painter.drawText(-40, y+5, str(i * 0.2)[:3])  # 刻度标签
            if i != 0:
                painter.setPen(QColor(250, 250, 250, 100))
                painter.drawLine(0, y, 500, y)
                painter.setPen(QColor("white"))

    def paint_point(self, painter):
        path = QPainterPath()
        for i, value in enumerate(self.data[0]):
            y = (1 - value) * 250
            x = i * 50
            point = QPointF(x, y)
            pen = QPen()
            pen.setWidth(3)
            painter.setPen(pen)
            if i == 0:
                path.moveTo(point)
            else:
                path.lineTo(point)
            # 绘制小圆点
            radius = 4
            pen.setColor(QColor("#91cc75"))
            painter.setPen(pen)
            painter.drawEllipse(point, radius, radius)
            pen.setColor(QColor(9, 118, 245))
            painter.setPen(pen)
        painter.drawPath(path)

    def paint_red_color(self,painter):
        or_brush = painter.brush()
        or_pen = painter.pen()
        painter.setPen(Qt.NoPen)
        for i, value in enumerate(self.data[0]):
            x = i * 50
            if value < 0.5:
                rect_x = x
                rect_y = 0
                # 绘制淡红色矩形
                painter.setBrush(QBrush(QColor(222, 26, 55, 120)))  # 淡红色
                painter.drawRect(rect_x, rect_y, 500 - rect_x, 250)
                break
        painter.setBrush(or_brush)
        painter.setPen(or_pen)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    scene = QGraphicsScene()
    Line_item = LineGraphItem()
    scene.addItem(Line_item)
    view = QGraphicsView(scene)
    view.show()
    app.exec_()

