from PyQt5.QtCore import pyqtSlot, Qt, QPoint, QRectF, QSize
from PyQt5.QtGui import QFont, QEnterEvent, QPixmap, QColor, QPainterPath, QPainter, QIcon, QBrush
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QDialog, QVBoxLayout, QPushButton, QHBoxLayout, QLabel
from PyQt5 import QtCore, QtWidgets


class CustomTitleBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(40)
        # 内容初始化
        layout = QHBoxLayout(self)

        self.label_icon = QLabel(self)
        # self.label_icon.setPixmap(icon.pixmap(30, 30))
        self.label_icon.setObjectName("icon")
        self.label_icon.setFixedSize(40,40)
        self.label_title = QLabel("RobustMIA Pro")
        self.minimize_button = QPushButton(self)
        self.maximize_button = QPushButton(self)
        self.close_button = QPushButton(self)

        self.label_title.setObjectName("label_title")
        self.minimize_button.setObjectName("minimize_button")
        self.maximize_button.setObjectName("maximize_button")
        self.close_button.setObjectName("close_button")
        layout.addWidget(self.label_icon)
        layout.addWidget(self.label_title)
        layout.addStretch(1)
        layout.addWidget(self.minimize_button)
        layout.addWidget(self.maximize_button)
        layout.addWidget(self.close_button)

        # 主窗口初始化设置
        self._init_main_window()

        # 设置 3 个按钮的图标字体

        icon1 = QIcon(":/image/res/最小化.png")
        icon2 = QIcon(":/image/res/放大.png")
        icon3 = QIcon(":/image/res/关闭_1.png")
        self.maximize_button.setIcon(icon2)
        self.minimize_button.setIcon(icon1)
        self.close_button.setIcon(icon3)
        self.close_button.clicked.connect(self.on_close_button_clicked)

        # 添加用于跟踪鼠标拖动的变量
        self.startMousePos = None
        self.startWindowPos = None

        # 设置QSS
        # 设置标题栏的背景颜色
        self.setStyleSheet("""
                            CustomTitleBar {
                                background: transparent;
                            }
                            QPushButton{
                                background: transparent;
                                color:white;
                                padding-bottom:15px;
                                }
                            QPushButton:hover{
                                padding-top:5px;
                                }
                            QLabel{
                                font-size: 18px;
                                font-family:Microsoft YaHei;
                                font-weight:bold;
                                color: white;
                                }
                            #icon{
                                padding-bottom: 15px;
                                image: url(":/image/res/RobustMIA_logo.png")
                                }
                        """)
        # 设置按钮大小
        button_size = QSize(40, 40)  # 设置按钮的大小为32x32像素
        self.minimize_button.setFixedSize(button_size)
        self.maximize_button.setFixedSize(button_size)
        self.close_button.setFixedSize(button_size)



    def _init_main_window(self):
        # 设置窗体无边框
        self.setWindowFlags(Qt.FramelessWindowHint)
        # 设置背景透明
        self.setAttribute(Qt.WA_TranslucentBackground)

    @pyqtSlot()
    def on_close_button_clicked(self):
        self.parent().close()

    def mousePressEvent(self, event):
        # 当鼠标按下时，记录鼠标的位置和窗口的位置
        self.startMousePos = event.globalPos()
        self.startWindowPos = self.window().frameGeometry().topLeft()

    def mouseMoveEvent(self, event):
        # 当鼠标移动时，如果鼠标按下的位置已经记录，那么移动窗口
        if self.startMousePos is not None:
            movePos = event.globalPos() - self.startMousePos
            self.window().move(self.startWindowPos + movePos)

    def mouseReleaseEvent(self, event):
        # 当鼠标释放时，清除记录的鼠标按下的位置
        self.startMousePos = None

