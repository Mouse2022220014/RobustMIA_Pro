import math
from PyQt5.QtWidgets import QApplication, QGraphicsView, QGraphicsItem, QGraphicsScene, QGraphicsPathItem, \
    QGraphicsDropShadowEffect, QGraphicsRectItem, QGraphicsTextItem
from PyQt5.QtGui import QPainter, QFont, QPainterPath, QColor, QPen, QFontMetricsF
from PyQt5.QtCore import QRectF, Qt, QPointF
import sys
# DDN和ERFPGM的位置换了
# 改了小矩形大小
# 设置默认全屏
class MyRectItem(QGraphicsRectItem):
    def __init__(self, words, scores):
        super().__init__()
        self.words = words
        self.scores = [round(score, 2) for score in scores]
        # 创建矩形
        self.rect = QGraphicsRectItem(-10, -10, 400, 210, self)

        self.rect.hide()

        # 切割
        word_score_list = list(zip(self.words, self.scores))
        first_part = word_score_list[:3]
        second_part = word_score_list[3:7]
        third_part = word_score_list[7:10]
        forth_part = word_score_list[10:15]
        fifth_part = word_score_list[15:21]

        # 将每部分的单词和分数转换为字符串，并用换行符连接
        first_part_str = '\n'.join([f'{word}: {score:>5}' for word, score in first_part])
        second_part_str = '\n'.join([f'{word}: {score:>5}' for word, score in second_part])
        third_part_str = '\n'.join([f'{word}: {score:>5}' for word, score in third_part])
        forth_part_str = '\n'.join([f'{word}: {score:>5}' for word, score in forth_part])
        fifth_part_str = '\n'.join([f'{word}: {score:>5}' for word, score in fifth_part])
        # 创建QGraphicsTextItem
        self.first_part_text = QGraphicsTextItem(first_part_str, self.rect)
        self.second_part_text = QGraphicsTextItem(second_part_str, self.rect)
        self.third_part_text = QGraphicsTextItem(third_part_str, self.rect)
        self.forth_part_text = QGraphicsTextItem(forth_part_str, self.rect)
        self.fifth_part_text = QGraphicsTextItem(fifth_part_str, self.rect)

        # 设置位置
        self.third_part_text.setPos(self.first_part_text.boundingRect().width(), 0)
        self.fifth_part_text.setPos(
            self.first_part_text.boundingRect().width() + self.second_part_text.boundingRect().width(), 0)
        self.forth_part_text.setPos(0, self.first_part_text.boundingRect().height() + 20)
        self.second_part_text.setPos(self.first_part_text.boundingRect().width(),
                                    self.first_part_text.boundingRect().height() + 20)
        # 矩形属性
        self.rect.setBrush(QColor("white"))
        pen = QPen(QColor(173, 216, 230))
        self.rect.setPen(pen)
        effect = QGraphicsDropShadowEffect()
        effect.setBlurRadius(10)
        effect.setColor(QColor(173, 216, 230))
        effect.setOffset(5)
        self.rect.setGraphicsEffect(effect)
        font = QFont()
        font.setFamily("Microsoft YaHei")
        font.setPixelSize(14)
        self.first_part_text.setFont(font)
        self.second_part_text.setFont(font)
        self.third_part_text.setFont(font)
        self.forth_part_text.setFont(font)
        self.fifth_part_text.setFont(font)
        self.setAcceptHoverEvents(True)

    def show_Rect(self, event):
        x = int(self.mapFromScene(event.pos()).x() + 20)
        y = int(self.mapFromScene(event.pos()).y())
        self.rect.setPos(x, y)
        self.rect.show()

    def hide_Rect(self):
        self.rect.hide()

class RadarItem(QGraphicsItem):
    def __init__(self, radar_data, radius, scene, color='blue'):
        super().__init__()
        self.color = color
        self.radius = radius
        self.path_area = None
        self.words = ['高斯噪声', '散斑噪声', 'ELD噪声', '高斯模糊', '运动模糊', 'JPEG压缩', '像素化  ', '亮度   ',
                      '对比度', '饱和度', '偏色', '旋转', '平移', '缩放', '畸变', 'FGSM ', 'MiM   ', 'PGD    ', 'C&W  ', 'ERFGSM',
                      'DDN   ']
        self.scores = radar_data
        self.font = QFont()
        self.font.setFamily("Microsoft YaHei")
        self.font.setPixelSize(20)
        self.font.setWeight(QFont.Bold)
        self.rect = MyRectItem(self.words, self.scores)

        scene.addItem(self.rect)
        self.rect.setZValue(100)

        self.setAcceptHoverEvents(True)

    def boundingRect(self):
        return QRectF(-self.radius, -self.radius, 2*self.radius, 2*self.radius)

    def paint(self, painter, option, widget):
        # 启用抗锯齿
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(QColor(0, 0, 0, 250))
        # 绘制椭圆
        for i in range(1, 5):
            painter.drawEllipse(self.boundingRect().center(), i*self.radius / 5, i*self.radius / 5)
        # 绘制底色
        self.paint_color(painter)
        # 计算字词位置并排列
        angle_step = 2*math.pi / len(self.words)
        for i, word in enumerate(self.words):
            angle = i * angle_step - math.pi/2
            x = (self.radius + 50) * math.cos(angle)
            y = (self.radius + 40) * math.sin(angle)
            line_end_x = self.radius * math.cos(angle)
            line_end_y = self.radius * math.sin(angle)
            painter.setPen(QColor(0, 0, 0, 100))
            painter.drawLine(self.boundingRect().center(),  QPointF(line_end_x, line_end_y))
            painter.setPen(QColor(255, 255, 255, 200))
            painter.setFont(self.font)
            painter.drawText(QPointF(x-30, y+7), word)
        # 判断输入哪个数据在用哪个
        # 绘制标蓝区域
        if self.color == 'blue':
            self.paint_score_blue(painter, angle_step)
        # 绘制标红区域
        else:
            self.paint_score_red(painter, angle_step)

    def paint_color(self,  painter):
        # 底色角度
        angle = 360 / 21
        a = -1.2 * angle
        b = 4 * angle - 1.2 * angle
        c = 3 * angle + b
        d = 6 * angle + c
        e = 4 * angle + d
        painter.setPen(Qt.NoPen) # 设置无色画笔
        # 上色
        path = QPainterPath()
        path.moveTo(self.boundingRect().center())
        path.arcTo(self.boundingRect(), a, 4 * angle)
        path.lineTo(self.boundingRect().center())
        painter.setBrush(QColor(177, 151, 252, 150))  # 浅紫
        painter.drawPath(path)

        path2 = QPainterPath()
        path2.moveTo(self.boundingRect().center())
        path2.arcTo(self.boundingRect(), b, 3 * angle)
        path2.lineTo(self.boundingRect().center())
        painter.setBrush(QColor(102, 217, 232, 150))  # 天蓝
        painter.drawPath(path2)
        #
        path3 = QPainterPath()
        path3.moveTo(self.boundingRect().center())
        path3.arcTo(self.boundingRect(), c, 6 * angle)
        path3.lineTo(self.boundingRect().center())
        painter.setBrush(QColor(255, 192, 120, 150))  # 橙色
        painter.drawPath(path3)

        path4 = QPainterPath()
        path4.moveTo(self.boundingRect().center())
        path4.arcTo(self.boundingRect(), d, 4 * angle)
        path4.lineTo(self.boundingRect().center())
        painter.setBrush(QColor(255, 135, 135, 150))  # 浅红
        painter.drawPath(path4)

        path5 = QPainterPath()
        path5.moveTo(self.boundingRect().center())
        path5.arcTo(self.boundingRect(), e, 4 * angle)
        path5.lineTo(self.boundingRect().center())
        painter.setBrush(QColor(192, 235, 117, 150))  # 浅绿
        painter.drawPath(path5)

    def paint_score_blue(self, painter, angle_steps):
        path = QPainterPath()

        for i, score in enumerate(self.scores):
            angle = i*angle_steps - math.pi/2
            r = self.radius * (score / 100)
            x = r * math.cos(angle)
            y = r * math.sin(angle)
            point = QPointF(x, y)
            pen = QPen()
            pen.setColor(QColor("#007FFF"))
            pen.setWidth(2)
            painter.setPen(pen)

            if i == 0:
                path.moveTo(point)
            else:
                path.lineTo(point)
        path.closeSubpath()  # 封闭连线

        painter.setBrush(QColor(102, 217, 232, 100))
        painter.drawPath(path)

        self.path_area = path

    def paint_score_red(self, painter, angle_steps):
        path = QPainterPath()

        for i, score in enumerate(self.scores):
            angle = i*angle_steps - math.pi/2
            r = self.radius * (score / 100)
            x = r * math.cos(angle)
            y = r * math.sin(angle)
            point = QPointF(x, y)
            pen = QPen()
            pen.setColor(QColor (255, 0, 0))
            pen.setWidth(2)
            painter.setPen(pen)

            if i == 0:
                path.moveTo(point)
            else:
                path.lineTo(point)
        path.closeSubpath()  # 封闭连线

        painter.setBrush(QColor(255, 192, 203, 100))
        painter.drawPath(path)

        self.path_area = path

    def hoverMoveEvent(self, event):
        if self.path_area.contains(event.pos()):
            self.rect.show_Rect(event)
        else:
            self.rect.hide_Rect()



class MyGraphicsView(QGraphicsView):
    def __init__(self, scene):
        super().__init__(scene)
        self.maxScaleFactor = 1.5 # 设置最大的缩放因子

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.fitInView(self.sceneRect(), Qt.KeepAspectRatio)
        # 检查当前的缩放因子，如果它超过了最大值，就将它设置为最大值
        if self.transform().m11() > self.maxScaleFactor:

            scaleFactor = self.maxScaleFactor / self.transform().m11()
            self.scale(scaleFactor, scaleFactor)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    scene = QGraphicsScene()
    Radar_item = RadarItem(250, scene)
    scene.addItem(Radar_item)
    view = MyGraphicsView(scene)
    view.show()
    app.exec_()