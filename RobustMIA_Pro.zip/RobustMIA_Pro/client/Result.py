import sys

from PyQt5.QtGui import QPalette, QColor, QFont, QIcon, QPainterPath, QPainter, QBrush
from PyQt5.QtWidgets import *
from PyQt5.QtCore import QRect, QPoint, Qt, QSize, QPropertyAnimation, QEasingCurve, QRectF
from client import Radar_Chart
from client import Line_Chart
from client import TitleBar

# 屏幕位移到中间的算法出了问题
# 雷达图没办法移到中间
class ResultPage(QMainWindow):
    def __init__(self, session):
        super().__init__(parent=None)
        # 自定义标题栏
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        TitleWindow = TitleBar.CustomTitleBar()
        self.setMenuWidget(TitleWindow)

        # QSS
        with open("./client/qss/style.qss", encoding='UTF-8') as f:
            self.setStyleSheet(f.read())

        # 设立传入数据
        self.point_line_data = session['point_line_data']
        self.radar_data = session['radar_data']
        self.model_name = session['model_name'].split('.')[0]
        self.model_score = session['score_sum']

        temp = self.radar_data[0][-1]
        self.radar_data[0][-1] = self.radar_data[0][-2]
        self.radar_data[0][-2] = temp

        temp = self.radar_data[1][-1]
        self.radar_data[1][-1] = self.radar_data[1][-2]
        self.radar_data[1][-2] = temp


        # 设置变量
        self.text_small = 16
        self.text_middle = 18
        self.text_big = 22
        self.radius = 200

        # 创建中心窗口
        central_widget = QWidget(self)
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)

        # 建立滚动条
        scroll_area = QScrollArea(self)
        scroll_area.setWidgetResizable(True)
        scrollable_widget = QWidget(self)
        scrollable_widget.setObjectName('scrollable_widget')
        scrollable_layout = QVBoxLayout(scrollable_widget)

        # 创建frame1和frame2
        self.frame_up = QFrame(self)
        self.frame_down = QFrame(self)

        # 添加frame1和frame2里的变量
        self.frame_Radar = QFrame(self.frame_up)
        self.frame_Radar.setObjectName('frame_Radar')

        self.frame_noise = QFrame(self.frame_down)
        self.frame_vague = QFrame(self.frame_down)
        self.frame_foundation = QFrame(self.frame_down)
        self.frame_motion = QFrame(self.frame_down)
        self.frame_FGSM = QFrame(self.frame_down)
        self.frame_noise.setObjectName('frame_noise')
        self.frame_vague.setObjectName('frame_vague')
        self.frame_foundation.setObjectName('frame_foundation')
        self.frame_motion.setObjectName('frame_motion')
        self.frame_FGSM.setObjectName('frame_FGSM')

        # 在可滚动的容器内部布置frame_up和frame_down
        scrollable_layout.addWidget(self.frame_up)
        scrollable_layout.addWidget(self.frame_down)

        # 将scrollable_widget设置为滚动区域的widget
        scroll_area.setWidget(scrollable_widget)

        # 将滚动区域添加到主布局
        layout.addWidget(scroll_area)

        # 运行函数
        self.init_Frame_up()
        self.init_Frame_down()

        # 连接按钮的点击信号到 ResultPage 的方法
        TitleWindow.minimize_button.clicked.connect(self.showMinimized)
        TitleWindow.maximize_button.clicked.connect(self.toggleMaximize)

        # 设置中心窗口
        self.setCentralWidget(central_widget)
        self.setGeometry(220, 5, 1528, 1070)
        # 最大化窗口

    def toggleMaximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def paint_Radar(self, layout, radius, data, color):
        scene = QGraphicsScene()
        radar_item = Radar_Chart.RadarItem(data, int(radius), scene, color)
        radar_item.setZValue(1)
        scene.addItem(radar_item)
        view = QGraphicsView()
        view.setScene(scene)
        view.setSceneRect(scene.itemsBoundingRect())
        view.centerOn(radar_item)
        layout.addWidget(view, 1)
        view.setStyleSheet("background: transparent; border: none;")

    def paint_Line(self, layout, data):
        scene = QGraphicsScene()
        line_item = Line_Chart.LineGraphItem(data)
        scene.addItem(line_item)
        view = QGraphicsView()
        view.setScene(scene)
        # 将整个视图缩放至指定比例尺
        scale_factor = 0.9
        view.scale(scale_factor, scale_factor)
        layout.addWidget(view)
        view.setStyleSheet("border: none; background: transparent; ")

    def setLabelStyle(self, label, text, fontsize, color, isBold = False):
        font = QFont()
        font.setFamily("Microsoft YaHei")
        label.setFont(font)
        label.setText(text)
        color = "255, 255, 255"
        fontSettings = f"font-size: {fontsize}px; color: rgba({color});"
        if isBold:
            fontSettings += " font-weight: bold;"
        label.setStyleSheet(fontSettings)

    def init_Frame_up(self):
        # 建立一个frame1的垂直布局
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(24, 24, 30, 20)

        # 建立label
        label_tip = QLabel('RobustMIA Pro 模型安全性测试报告', self.frame_up)
        label_tip.setObjectName('label_tip')

        label_model_name = QLabel(str(self.model_name)+'的测试分数:       ', self.frame_up)
        label_model_name.setObjectName('label_model_name')

        label_score = QLabel(str(self.model_score), self.frame_up)
        label_score.setObjectName('label_score')

        label_tip1 = QLabel('整体评分:', self.frame_up)
        label_tip1.setObjectName('label_tip1')

        label_tip2 = QLabel('极端值评分:', self.frame_up)
        label_tip2.setObjectName('label_tip2')


        # 建立label之间的水平布局
        label_layout = QHBoxLayout()

        # 建立label和雷达图之间的垂直布局
        Radar_layout_left = QVBoxLayout()
        Radar_layout_right = QVBoxLayout()

        # 建立雷达图之间的水平布局
        Radar_layout = QHBoxLayout()

        # 建立雷达图并和label绑定
        Radar_layout_left.addWidget(label_tip1)
        self.paint_Radar(Radar_layout_left, self.radius, self.radar_data[0], 'blue')

        Radar_layout_right.addWidget(label_tip2)
        self.paint_Radar(Radar_layout_right, self.radius, self.radar_data[1], 'red')

        # 雷达图绑定并加入frame_Radar
        Radar_layout.addLayout(Radar_layout_left, 1)
        Radar_layout.addLayout(Radar_layout_right, 1)

        self.frame_Radar.setLayout(Radar_layout)
        self.frame_Radar.setFixedHeight(600)

        # label左右绑定
        label_layout.addWidget(label_model_name)
        label_layout.addWidget(label_score)
        label_layout.addStretch(1)

        # 添加总体布局
        main_layout.addWidget(label_tip)
        main_layout.addSpacing(20)
        main_layout.addLayout(label_layout)
        main_layout.addSpacing(23)
        main_layout.addWidget(self.frame_Radar)

        self.frame_up.setLayout(main_layout)

    def init_Frame_down(self):
        # 建立一个frame2的垂直布局
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(25, 0, 30, 20)

        # 建立五个frame
        # 设置frame的高度
        self.frame_noise.setFixedHeight(800)
        self.frame_vague.setFixedHeight(800)
        self.frame_foundation.setFixedHeight(1950)
        self.frame_motion.setFixedHeight(1950)
        self.frame_FGSM.setFixedHeight(2100)

        # 添加frame
        main_layout.addWidget(self.frame_noise)
        main_layout.addWidget(self.frame_vague)
        main_layout.addWidget(self.frame_foundation)
        main_layout.addWidget(self.frame_motion)
        main_layout.addWidget(self.frame_FGSM)

        # 添加布局
        self.frame_down.setLayout(main_layout)

        # 添加折线图
        self.frame_noise_paint()
        self.frame_vague_paint()
        self.frame_foundation_paint()
        self.frame_motion_paint()
        self.frame_FGSM_paint()

    def frame_noise_paint(self):
        # 创建一个网格布局
        grid_layout = QGridLayout(self.frame_noise)

        # 创建三个垂直布局
        vertical_layout1 = QVBoxLayout(self.frame_noise)
        vertical_layout2 = QVBoxLayout(self.frame_noise)
        vertical_layout3 = QVBoxLayout(self.frame_noise)
        # 创建三个布局各自的两个标签
        label_Gaosi = QLabel("高斯噪声")
        label_Sanban = QLabel("散斑噪声")
        label_ELD = QLabel("ELD噪声")
        label_tip1_1 = QLabel("强度——模型accuracy比值")
        label_tip2_1 = QLabel("扰动强度")
        label_tip1_2 = QLabel("强度——模型accuracy比值")
        label_tip2_2 = QLabel("扰动强度")
        label_tip1_3 = QLabel("强度——模型accuracy比值")
        label_tip2_3 = QLabel("扰动强度")
        self.setLabelStyle(label_Gaosi, "高斯噪声", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_Sanban, "散斑噪声", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_ELD, "ELD噪声", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_tip1_1, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_1, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_2, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_2, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_3, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_3, "扰动强度", self.text_small, "0, 0, 0, 150")

        # 将控件添加到垂直布局中
        vertical_layout1.addWidget(label_Gaosi)
        vertical_layout1.addWidget(label_tip1_1)
        self.paint_Line(vertical_layout1, self.point_line_data[0])
        label_tip2_1.setAlignment(Qt.AlignHCenter)
        vertical_layout1.addWidget(label_tip2_1)

        vertical_layout2.addWidget(label_Sanban)
        vertical_layout2.addWidget(label_tip1_2)
        self.paint_Line(vertical_layout2, self.point_line_data[1])
        label_tip2_2.setAlignment(Qt.AlignHCenter)
        vertical_layout2.addWidget(label_tip2_2)

        vertical_layout3.addWidget(label_ELD)
        vertical_layout3.addWidget(label_tip1_3)
        self.paint_Line(vertical_layout3, self.point_line_data[2])
        label_tip2_3.setAlignment(Qt.AlignHCenter)
        vertical_layout3.addWidget(label_tip2_3)

        # 将布局添加到网格指定位置
        grid_layout.addLayout(vertical_layout1, 0, 0)
        grid_layout.addLayout(vertical_layout2, 0, 1)
        grid_layout.addLayout(vertical_layout3, 1, 0, 1, 1)

        # 设置网格布局的边距和间距
        grid_layout.setContentsMargins(10, 10, 10, 10)
        grid_layout.setHorizontalSpacing(10)
        grid_layout.setVerticalSpacing(10)

    def frame_vague_paint(self):
        # 创建一个网格布局
        grid_layout = QGridLayout(self.frame_vague)

        # 创建四个垂直布局
        vertical_layout1 = QVBoxLayout(self.frame_vague)
        vertical_layout2 = QVBoxLayout(self.frame_vague)
        vertical_layout3 = QVBoxLayout(self.frame_vague)
        vertical_layout4 = QVBoxLayout(self.frame_vague)

        # 创建四个布局各自的两个标签
        label_Gaosi = QLabel("高斯模糊")
        label_Yundong = QLabel("运动模糊")
        label_JPEG = QLabel("JPEG压缩")
        label_xp = QLabel("像素化")
        label_tip1_1 = QLabel("强度——模型accuracy比值")
        label_tip2_1 = QLabel("扰动强度")
        label_tip1_2 = QLabel("强度——模型accuracy比值")
        label_tip2_2 = QLabel("扰动强度")
        label_tip1_3 = QLabel("强度——模型accuracy比值")
        label_tip2_3 = QLabel("扰动强度")
        label_tip1_4 = QLabel("强度——模型accuracy比值")
        label_tip2_4 = QLabel("扰动强度")
        self.setLabelStyle(label_Gaosi, "高斯模糊", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_Yundong, "运动模糊", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_JPEG, "JPEG压缩", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_xp, "像素化", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_tip1_1, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_1, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_2, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_2, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_3, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_3, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_4, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_4, "扰动强度", self.text_small, "0, 0, 0, 150")
        # 将控件添加到垂直布局中
        vertical_layout1.addWidget(label_Gaosi)
        vertical_layout1.addWidget(label_tip1_1)
        self.paint_Line(vertical_layout1, self.point_line_data[3])
        label_tip2_1.setAlignment(Qt.AlignHCenter)
        vertical_layout1.addWidget(label_tip2_1)

        vertical_layout2.addWidget(label_Yundong)
        vertical_layout2.addWidget(label_tip1_2)
        self.paint_Line(vertical_layout2, self.point_line_data[4])
        label_tip2_2.setAlignment(Qt.AlignHCenter)
        vertical_layout2.addWidget(label_tip2_2)

        vertical_layout3.addWidget(label_JPEG)
        vertical_layout3.addWidget(label_tip1_3)
        self.paint_Line(vertical_layout3, self.point_line_data[5])
        label_tip2_3.setAlignment(Qt.AlignHCenter)
        vertical_layout3.addWidget(label_tip2_3)

        vertical_layout4.addWidget(label_xp)
        vertical_layout4.addWidget(label_tip1_4)
        self.paint_Line(vertical_layout4, self.point_line_data[6])
        label_tip2_4.setAlignment(Qt.AlignHCenter)
        vertical_layout4.addWidget(label_tip2_4)

        # 将布局添加到网格指定位置
        grid_layout.addLayout(vertical_layout1, 0, 0)
        grid_layout.addLayout(vertical_layout2, 0, 1)
        grid_layout.addLayout(vertical_layout3, 1, 0)
        grid_layout.addLayout(vertical_layout4, 1, 1)

        # 设置网格布局的边距和间距
        grid_layout.setContentsMargins(10, 10, 10, 10)
        grid_layout.setHorizontalSpacing(10)
        grid_layout.setVerticalSpacing(10)

    def frame_foundation_paint(self):
        # 创建一个网格布局
        grid_layout = QGridLayout(self.frame_foundation)

        # 创建九个垂直布局
        vertical_layout1 = QVBoxLayout(self.frame_foundation)
        vertical_layout2 = QVBoxLayout(self.frame_foundation)
        vertical_layout3 = QVBoxLayout(self.frame_foundation)
        vertical_layout4 = QVBoxLayout(self.frame_foundation)
        vertical_layout5 = QVBoxLayout(self.frame_foundation)
        vertical_layout6 = QVBoxLayout(self.frame_foundation)
        vertical_layout7 = QVBoxLayout(self.frame_foundation)
        vertical_layout8 = QVBoxLayout(self.frame_foundation)
        vertical_layout9 = QVBoxLayout(self.frame_foundation)

        # 创建四个布局各自的两个标签
        label_Flash_up = QLabel("亮度(上升)")
        label_Flash_down = QLabel("亮度(下降)")
        label_Duibidu_up = QLabel("对比度(上升)")
        label_Diubidu_down = QLabel("对比度(下降)")
        label_Baohedu_up = QLabel("饱和度(上升)")
        label_Baohedu_down = QLabel("饱和度(下降)")
        label_red = QLabel("偏色(红)")
        label_green = QLabel("偏色(绿)")
        label_blue = QLabel("偏色(蓝)")
        label_tip1_1 = QLabel("强度——模型accuracy比值")
        label_tip2_1 = QLabel("扰动强度")
        label_tip1_2 = QLabel("强度——模型accuracy比值")
        label_tip2_2 = QLabel("扰动强度")
        label_tip1_3 = QLabel("强度——模型accuracy比值")
        label_tip2_3 = QLabel("扰动强度")
        label_tip1_4 = QLabel("强度——模型accuracy比值")
        label_tip2_4 = QLabel("扰动强度")
        label_tip1_5 = QLabel("强度——模型accuracy比值")
        label_tip2_5 = QLabel("扰动强度")
        label_tip1_6 = QLabel("强度——模型accuracy比值")
        label_tip2_6 = QLabel("扰动强度")
        label_tip1_7 = QLabel("强度——模型accuracy比值")
        label_tip2_7 = QLabel("扰动强度")
        label_tip1_8 = QLabel("强度——模型accuracy比值")
        label_tip2_8 = QLabel("扰动强度")
        label_tip1_9 = QLabel("强度——模型accuracy比值")
        label_tip2_9 = QLabel("扰动强度")
        self.setLabelStyle(label_Flash_up, "亮度(上升)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_Flash_down, "亮度(下降)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_Duibidu_up, "对比度(上升)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_Diubidu_down, "对比度(下降)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_Baohedu_up, "饱和度(上升)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_Baohedu_down, "饱和度(下降)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_red, "偏色(红)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_green, "偏色(绿)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_blue, "偏色(蓝)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_tip1_1, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_1, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_2, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_2, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_3, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_3, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_4, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_4, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_5, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_5, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_6, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_6, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_7, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_7, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_8, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_8, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_9, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_9, "扰动强度", self.text_small, "0, 0, 0, 150")
        # 将控件添加到垂直布局中
        vertical_layout1.addWidget(label_Flash_up)
        vertical_layout1.addWidget(label_tip1_1)
        self.paint_Line(vertical_layout1, self.point_line_data[7])
        label_tip2_1.setAlignment(Qt.AlignHCenter)
        vertical_layout1.addWidget(label_tip2_1)

        vertical_layout2.addWidget(label_Flash_down)
        vertical_layout2.addWidget(label_tip1_2)
        self.paint_Line(vertical_layout2, self.point_line_data[8])
        label_tip2_2.setAlignment(Qt.AlignHCenter)
        vertical_layout2.addWidget(label_tip2_2)

        vertical_layout3.addWidget(label_Duibidu_up)
        vertical_layout3.addWidget(label_tip1_3)
        self.paint_Line(vertical_layout3, self.point_line_data[9])
        label_tip2_3.setAlignment(Qt.AlignHCenter)
        vertical_layout3.addWidget(label_tip2_3)

        vertical_layout4.addWidget(label_Diubidu_down)
        vertical_layout4.addWidget(label_tip1_4)
        self.paint_Line(vertical_layout4, self.point_line_data[10])
        label_tip2_4.setAlignment(Qt.AlignHCenter)
        vertical_layout4.addWidget(label_tip2_4)

        vertical_layout5.addWidget(label_Baohedu_up)
        vertical_layout5.addWidget(label_tip1_5)
        self.paint_Line(vertical_layout5, self.point_line_data[11])
        label_tip2_5.setAlignment(Qt.AlignHCenter)
        vertical_layout5.addWidget(label_tip2_5)

        vertical_layout6.addWidget(label_Baohedu_down)
        vertical_layout6.addWidget(label_tip1_6)
        self.paint_Line(vertical_layout6, self.point_line_data[12])
        label_tip2_6.setAlignment(Qt.AlignHCenter)
        vertical_layout6.addWidget(label_tip2_6)

        vertical_layout7.addWidget(label_red)
        vertical_layout7.addWidget(label_tip1_7)
        self.paint_Line(vertical_layout7, self.point_line_data[13])
        label_tip2_7.setAlignment(Qt.AlignHCenter)
        vertical_layout7.addWidget(label_tip2_7)

        vertical_layout8.addWidget(label_green)
        vertical_layout8.addWidget(label_tip1_8)
        self.paint_Line(vertical_layout8, self.point_line_data[14])
        label_tip2_8.setAlignment(Qt.AlignHCenter)
        vertical_layout8.addWidget(label_tip2_8)

        vertical_layout9.addWidget(label_blue)
        vertical_layout9.addWidget(label_tip1_9)
        self.paint_Line(vertical_layout9, self.point_line_data[15])
        label_tip2_9.setAlignment(Qt.AlignHCenter)
        vertical_layout9.addWidget(label_tip2_9)

        # 将布局添加到网格指定位置
        grid_layout.addLayout(vertical_layout1, 0, 0)
        grid_layout.addLayout(vertical_layout2, 0, 1)
        grid_layout.addLayout(vertical_layout3, 1, 0)
        grid_layout.addLayout(vertical_layout4, 1, 1)
        grid_layout.addLayout(vertical_layout5, 2, 0)
        grid_layout.addLayout(vertical_layout6, 2, 1)
        grid_layout.addLayout(vertical_layout7, 3, 0)
        grid_layout.addLayout(vertical_layout8, 3, 1)
        grid_layout.addLayout(vertical_layout9, 4, 0)

        # 设置网格布局的边距和间距
        grid_layout.setContentsMargins(10, 10, 10, 10)
        grid_layout.setHorizontalSpacing(10)
        grid_layout.setVerticalSpacing(10)

    def frame_motion_paint(self):
        # 创建一个网格布局
        grid_layout = QGridLayout(self.frame_motion)

        # 创建十个垂直布局
        vertical_layout1 = QVBoxLayout(self.frame_motion)
        vertical_layout2 = QVBoxLayout(self.frame_motion)
        vertical_layout3 = QVBoxLayout(self.frame_motion)
        vertical_layout4 = QVBoxLayout(self.frame_motion)
        vertical_layout5 = QVBoxLayout(self.frame_motion)
        vertical_layout6 = QVBoxLayout(self.frame_motion)
        vertical_layout7 = QVBoxLayout(self.frame_motion)
        vertical_layout8 = QVBoxLayout(self.frame_motion)
        vertical_layout9 = QVBoxLayout(self.frame_motion)
        vertical_layout10 = QVBoxLayout(self.frame_motion)

        # 创建四个布局各自的两个标签
        label_Xuanzhuang = QLabel("旋转")
        label_right = QLabel("平移(右)")
        label_left = QLabel("平移(左)")
        label_up = QLabel("平移(上)")
        label_down = QLabel("平移(下)")
        label_wight = QLabel("缩放(宽度)")
        label_hight = QLabel("缩放(高度)")
        label_all = QLabel("缩放(整体)")
        label_Tongxing = QLabel("畸变(桶形)")
        label_Zhenxing = QLabel("畸变(枕形")
        label_tip1_1 = QLabel("强度——模型accuracy比值")
        label_tip2_1 = QLabel("扰动强度")
        label_tip1_2 = QLabel("强度——模型accuracy比值")
        label_tip2_2 = QLabel("扰动强度")
        label_tip1_3 = QLabel("强度——模型accuracy比值")
        label_tip2_3 = QLabel("扰动强度")
        label_tip1_4 = QLabel("强度——模型accuracy比值")
        label_tip2_4 = QLabel("扰动强度")
        label_tip1_5 = QLabel("强度——模型accuracy比值")
        label_tip2_5 = QLabel("扰动强度")
        label_tip1_6 = QLabel("强度——模型accuracy比值")
        label_tip2_6 = QLabel("扰动强度")
        label_tip1_7 = QLabel("强度——模型accuracy比值")
        label_tip2_7 = QLabel("扰动强度")
        label_tip1_8 = QLabel("强度——模型accuracy比值")
        label_tip2_8 = QLabel("扰动强度")
        label_tip1_9 = QLabel("强度——模型accuracy比值")
        label_tip2_9 = QLabel("扰动强度")
        label_tip1_10 = QLabel("强度——模型accuracy比值")
        label_tip2_10 = QLabel("扰动强度")
        self.setLabelStyle(label_Xuanzhuang, "旋转", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_right, "平移(右)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_left, "平移(左)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_up, "平移(上)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_down, "平移(下)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_wight, "缩放(宽度)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_hight, "缩放(高度)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_all, "缩放(整体)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_Tongxing, "畸变(桶形)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_Zhenxing, "畸变(枕形)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_tip1_1, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_1, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_2, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_2, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_3, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_3, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_4, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_4, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_5, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_5, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_6, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_6, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_7, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_7, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_8, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_8, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_9, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_9, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_10, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_10, "扰动强度", self.text_small, "0, 0, 0, 150")
        # 将控件添加到垂直布局中
        vertical_layout1.addWidget(label_Xuanzhuang)
        vertical_layout1.addWidget(label_tip1_1)
        self.paint_Line(vertical_layout1, self.point_line_data[16])
        label_tip2_1.setAlignment(Qt.AlignHCenter)
        vertical_layout1.addWidget(label_tip2_1)

        vertical_layout2.addWidget(label_right)
        vertical_layout2.addWidget(label_tip1_2)
        self.paint_Line(vertical_layout2, self.point_line_data[17])
        label_tip2_2.setAlignment(Qt.AlignHCenter)
        vertical_layout2.addWidget(label_tip2_2)

        vertical_layout3.addWidget(label_left)
        vertical_layout3.addWidget(label_tip1_3)
        self.paint_Line(vertical_layout3, self.point_line_data[18])
        label_tip2_3.setAlignment(Qt.AlignHCenter)
        vertical_layout3.addWidget(label_tip2_3)

        vertical_layout4.addWidget(label_up)
        vertical_layout4.addWidget(label_tip1_4)
        self.paint_Line(vertical_layout4, self.point_line_data[19])
        label_tip2_4.setAlignment(Qt.AlignHCenter)
        vertical_layout4.addWidget(label_tip2_4)

        vertical_layout5.addWidget(label_down)
        vertical_layout5.addWidget(label_tip1_5)
        self.paint_Line(vertical_layout5, self.point_line_data[20])
        label_tip2_5.setAlignment(Qt.AlignHCenter)
        vertical_layout5.addWidget(label_tip2_5)

        vertical_layout6.addWidget(label_wight)
        vertical_layout6.addWidget(label_tip1_6)
        self.paint_Line(vertical_layout6, self.point_line_data[21])
        label_tip2_6.setAlignment(Qt.AlignHCenter)
        vertical_layout6.addWidget(label_tip2_6)

        vertical_layout7.addWidget(label_hight)
        vertical_layout7.addWidget(label_tip1_7)
        self.paint_Line(vertical_layout7, self.point_line_data[22])
        label_tip2_7.setAlignment(Qt.AlignHCenter)
        vertical_layout7.addWidget(label_tip2_7)

        vertical_layout8.addWidget(label_all)
        vertical_layout8.addWidget(label_tip1_8)
        self.paint_Line(vertical_layout8, self.point_line_data[23])
        label_tip2_8.setAlignment(Qt.AlignHCenter)
        vertical_layout8.addWidget(label_tip2_8)

        vertical_layout9.addWidget(label_Tongxing)
        vertical_layout9.addWidget(label_tip1_9)
        self.paint_Line(vertical_layout9, self.point_line_data[24])
        label_tip2_9.setAlignment(Qt.AlignHCenter)
        vertical_layout9.addWidget(label_tip2_9)

        vertical_layout10.addWidget(label_Zhenxing)
        vertical_layout10.addWidget(label_tip1_10)
        self.paint_Line(vertical_layout10, self.point_line_data[25])
        label_tip2_10.setAlignment(Qt.AlignHCenter)
        vertical_layout10.addWidget(label_tip2_10)

        # 将布局添加到网格指定位置
        grid_layout.addLayout(vertical_layout1, 0, 0)
        grid_layout.addLayout(vertical_layout2, 0, 1)
        grid_layout.addLayout(vertical_layout3, 1, 0)
        grid_layout.addLayout(vertical_layout4, 1, 1)
        grid_layout.addLayout(vertical_layout5, 2, 0)
        grid_layout.addLayout(vertical_layout6, 2, 1)
        grid_layout.addLayout(vertical_layout7, 3, 0)
        grid_layout.addLayout(vertical_layout8, 3, 1)
        grid_layout.addLayout(vertical_layout9, 4, 0)
        grid_layout.addLayout(vertical_layout10, 4, 1)

        # 设置网格布局的边距和间距
        grid_layout.setContentsMargins(10, 10, 10, 10)
        grid_layout.setHorizontalSpacing(10)
        grid_layout.setVerticalSpacing(10)

    def frame_FGSM_paint(self):
        # 创建一个网格布局
        grid_layout = QGridLayout(self.frame_FGSM)

        # 创建十个垂直布局
        vertical_layout1 = QVBoxLayout(self.frame_FGSM)
        vertical_layout2 = QVBoxLayout(self.frame_FGSM)
        vertical_layout3 = QVBoxLayout(self.frame_FGSM)
        vertical_layout4 = QVBoxLayout(self.frame_FGSM)
        vertical_layout5 = QVBoxLayout(self.frame_FGSM)
        vertical_layout6 = QVBoxLayout(self.frame_FGSM)
        vertical_layout7 = QVBoxLayout(self.frame_FGSM)
        vertical_layout8 = QVBoxLayout(self.frame_FGSM)
        vertical_layout9 = QVBoxLayout(self.frame_FGSM)
        vertical_layout10 = QVBoxLayout(self.frame_FGSM)
        vertical_layout11 = QVBoxLayout(self.frame_FGSM)

        # 创建四个布局各自的两个标签
        label_FGSM = QLabel("FGSM(目标)")
        label_FGSM_NO = QLabel("FGSM(非目标)")
        label_MiMi = QLabel("MiM(目标)")
        label_MiMi_NO = QLabel("MiM(非目标)")
        label_PGD = QLabel("PGD(目标)")
        label_PGD_NO = QLabel("PGD(非目标)")
        label_CW = QLabel("C&W(目标)")
        label_CW_NO = QLabel("C&W(非目标)")
        label_DDN = QLabel("DDN(目标)")
        label_DDN_NO = QLabel("DDN(非目标)")
        label_ERFGSM = QLabel("ERFGSM")
        label_tip1_1 = QLabel("强度——模型accuracy比值")
        label_tip2_1 = QLabel("扰动强度")
        label_tip1_2 = QLabel("强度——模型accuracy比值")
        label_tip2_2 = QLabel("扰动强度")
        label_tip1_3 = QLabel("强度——模型accuracy比值")
        label_tip2_3 = QLabel("扰动强度")
        label_tip1_4 = QLabel("强度——模型accuracy比值")
        label_tip2_4 = QLabel("扰动强度")
        label_tip1_5 = QLabel("强度——模型accuracy比值")
        label_tip2_5 = QLabel("扰动强度")
        label_tip1_6 = QLabel("强度——模型accuracy比值")
        label_tip2_6 = QLabel("扰动强度")
        label_tip1_7 = QLabel("强度——模型accuracy比值")
        label_tip2_7 = QLabel("扰动强度")
        label_tip1_8 = QLabel("强度——模型accuracy比值")
        label_tip2_8 = QLabel("扰动强度")
        label_tip1_9 = QLabel("强度——模型accuracy比值")
        label_tip2_9 = QLabel("扰动强度")
        label_tip1_10 = QLabel("强度——模型accuracy比值")
        label_tip2_10 = QLabel("扰动强度")
        label_tip1_11 = QLabel("强度——模型accuracy比值")
        label_tip2_11 = QLabel("扰动强度")
        self.setLabelStyle(label_FGSM, "FGSM(目标)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_FGSM_NO, "FGSM(非目标)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_MiMi, "MiM(目标)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_MiMi_NO, "MiM(非目标)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_PGD, "PGD(目标)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_PGD_NO, "PGD(非目标)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_CW, "C&W(目标)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_CW_NO, "C&W(非目标)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_DDN, "DDN(目标)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_DDN_NO, "DDN(非目标)", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_ERFGSM, "ERFGSM", self.text_big, "0, 0, 0, 255", isBold=True)
        self.setLabelStyle(label_tip1_1, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_1, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_2, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_2, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_3, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_3, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_4, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_4, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_5, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_5, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_6, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_6, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_7, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_7, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_8, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_8, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_9, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_9, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_10, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_10, "扰动强度", self.text_small, "0, 0, 0, 150")
        self.setLabelStyle(label_tip1_11, "强度——模型accuracy比值", self.text_middle, "0, 0, 0, 150")
        self.setLabelStyle(label_tip2_11, "扰动强度", self.text_small, "0, 0, 0, 150")

        # 将控件添加到垂直布局中
        vertical_layout1.addWidget(label_FGSM)
        vertical_layout1.addWidget(label_tip1_1)
        self.paint_Line(vertical_layout1, self.point_line_data[26])
        label_tip2_1.setAlignment(Qt.AlignHCenter)
        vertical_layout1.addWidget(label_tip2_1)

        vertical_layout2.addWidget(label_FGSM_NO)
        vertical_layout2.addWidget(label_tip1_2)
        self.paint_Line(vertical_layout2, self.point_line_data[27])
        label_tip2_2.setAlignment(Qt.AlignHCenter)
        vertical_layout2.addWidget(label_tip2_2)

        vertical_layout3.addWidget(label_MiMi)
        vertical_layout3.addWidget(label_tip1_3)
        self.paint_Line(vertical_layout3, self.point_line_data[28])
        label_tip2_3.setAlignment(Qt.AlignHCenter)
        vertical_layout3.addWidget(label_tip2_3)

        vertical_layout4.addWidget(label_MiMi_NO)
        vertical_layout4.addWidget(label_tip1_4)
        self.paint_Line(vertical_layout4, self.point_line_data[29])
        label_tip2_4.setAlignment(Qt.AlignHCenter)
        vertical_layout4.addWidget(label_tip2_4)

        vertical_layout5.addWidget(label_PGD)
        vertical_layout5.addWidget(label_tip1_5)
        self.paint_Line(vertical_layout5, self.point_line_data[30])
        label_tip2_5.setAlignment(Qt.AlignHCenter)
        vertical_layout5.addWidget(label_tip2_5)

        vertical_layout6.addWidget(label_PGD_NO)
        vertical_layout6.addWidget(label_tip1_6)
        self.paint_Line(vertical_layout6, self.point_line_data[31])
        label_tip2_6.setAlignment(Qt.AlignHCenter)
        vertical_layout6.addWidget(label_tip2_6)

        vertical_layout7.addWidget(label_CW)
        vertical_layout7.addWidget(label_tip1_7)
        self.paint_Line(vertical_layout7, self.point_line_data[32])
        label_tip2_7.setAlignment(Qt.AlignHCenter)
        vertical_layout7.addWidget(label_tip2_7)

        vertical_layout8.addWidget(label_CW_NO)
        vertical_layout8.addWidget(label_tip1_8)
        self.paint_Line(vertical_layout8, self.point_line_data[33])
        label_tip2_8.setAlignment(Qt.AlignHCenter)
        vertical_layout8.addWidget(label_tip2_8)

        vertical_layout9.addWidget(label_DDN)
        vertical_layout9.addWidget(label_tip1_9)
        self.paint_Line(vertical_layout9, self.point_line_data[34])
        label_tip2_9.setAlignment(Qt.AlignHCenter)
        vertical_layout9.addWidget(label_tip2_9)

        vertical_layout10.addWidget(label_DDN_NO)
        vertical_layout10.addWidget(label_tip1_10)
        self.paint_Line(vertical_layout10, self.point_line_data[35])
        label_tip2_10.setAlignment(Qt.AlignHCenter)
        vertical_layout10.addWidget(label_tip2_10)

        vertical_layout11.addWidget(label_ERFGSM)
        vertical_layout11.addWidget(label_tip1_11)
        self.paint_Line(vertical_layout11, self.point_line_data[36])
        label_tip2_11.setAlignment(Qt.AlignHCenter)
        vertical_layout11.addWidget(label_tip2_11)
        # 将布局添加到网格指定位置
        grid_layout.addLayout(vertical_layout1, 0, 0)
        grid_layout.addLayout(vertical_layout2, 0, 1)
        grid_layout.addLayout(vertical_layout3, 1, 0)
        grid_layout.addLayout(vertical_layout4, 1, 1)
        grid_layout.addLayout(vertical_layout5, 2, 0)
        grid_layout.addLayout(vertical_layout6, 2, 1)
        grid_layout.addLayout(vertical_layout7, 3, 0)
        grid_layout.addLayout(vertical_layout8, 3, 1)
        grid_layout.addLayout(vertical_layout9, 4, 0)
        grid_layout.addLayout(vertical_layout10, 4, 1)
        grid_layout.addLayout(vertical_layout11, 5, 0)
        # 设置网格布局的边距和间距
        grid_layout.setContentsMargins(10, 10, 10, 10)
        grid_layout.setHorizontalSpacing(10)
        grid_layout.setVerticalSpacing(10)

    def paintEvent(self, event):
        path = QPainterPath()
        rect = QRectF(self.rect())
        path.addRoundedRect(rect, 10, 10)  # 设置弧度为 10
        painter = QPainter(self)
        painter.fillPath(path, QBrush(QColor("#42464d")))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    with open("style.qss", encoding='UTF-8') as f:
        app.setStyleSheet(f.read())
    window = ResultPage()
    window.show()
    sys.exit(app.exec_())

