from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout, QHBoxLayout, QApplication
from PyQt5.QtGui import QIcon, QPixmap
import sys


class PushButton_icon_with_label(QWidget):
    clicked = pyqtSignal()
    enter = pyqtSignal(str)
    select = False

    def __init__(self, parent=None):
        super().__init__(parent)
        self.resize(199, 62)
        self.layout = QHBoxLayout(self)
        self.layout.setSpacing(0)
        self.layout.setContentsMargins(0,0,0,0)
        self.central_widget = QWidget(self)
        self.layout.addWidget(self.central_widget)
        self.layout_2 = QHBoxLayout(self.central_widget)

        self.icon_label = QLabel(self)

        self.text_label = QLabel(self)
        self.text_label.setAlignment(Qt.AlignVCenter)

        self.layout_2.addWidget(self.icon_label, 18)
        self.layout_2.addWidget(self.text_label, 72)

        self.layout_2.setSpacing(10)
        self.layout_2.setContentsMargins(24, 22, 27, 22)
        self.setMouseTracking(True)

        self.set_qss()


    def set_qss(self, mode='normal'):
        if mode == 'normal':
            with open('./client/qss/pushButton_menu.qss') as f:
                self.setStyleSheet(f.read())

        elif mode == 'hover':
            with open('./client/qss/pushButton_menu_hover.qss') as f:
                self.setStyleSheet(f.read())

        elif mode == 'check':
            with open('./client/qss/pushButton_menu_checked.qss') as f:
                self.setStyleSheet(f.read())

    def set_text(self, text):
        self.text_label.setText(text)

    def set_icon(self, icon_default):
        icon_default = QPixmap(icon_default)
        icon_default = icon_default.scaled(20, 20)
        self.icon_label.setPixmap(icon_default)

    def enterEvent(self, event):
        if self.select == False:
            self.set_qss('hover')

    def leaveEvent(self, event):
        if self.select == False:
            self.set_qss('normal')

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        if event.button() == Qt.LeftButton:
            self.set_qss("check")

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        if event.button() == Qt.LeftButton:
            self.clicked.emit()


class PushButton_icon_with_label_bottom(QWidget):
    clicked = pyqtSignal()
    pressed = pyqtSignal(str)
    select = False

    def __init__(self, parent=None):
        super().__init__(parent)
        self.resize(240, 272)
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)

        self.central_widget = QWidget(self)
        self.layout.addWidget(self.central_widget)
        self.layout_2 = QVBoxLayout(self.central_widget)
        self.layout_2.setContentsMargins(60, 34, 60, 33)
        self.layout_2.setSpacing(45)
        self.icon_label = QLabel(self)
        self.icon_label.setAlignment(Qt.AlignCenter)
        self.text_label = QLabel(self)
        self.text_label.setAlignment(Qt.AlignCenter)
        self.layout_2.addWidget(self.icon_label,108)
        self.layout_2.addWidget(self.text_label,30)

        self.set_qss()

    def set_qss(self, mode='normal'):
        if mode == 'normal':
            with open('./client/qss/pushButton_model.qss') as f:
                self.setStyleSheet(f.read())

        elif mode == 'hover':
            with open('./client/qss/pushButton_model_hover.qss') as f:
                self.setStyleSheet(f.read())

        elif mode == 'check':
            with open('./client/qss/pushButton_model_checked.qss') as f:
                self.setStyleSheet(f.read())


    def set_text(self, text):
        self.text_label.setText(text)

    def set_icon(self, icon_default):
        icon_default = QPixmap(icon_default)
        icon_default = icon_default.scaled(100, 100)
        self.icon_label.setPixmap(icon_default)

    def enterEvent(self, event):
        if self.select == False:
            self.set_qss('hover')

    def leaveEvent(self, event):
        if self.select == False:
            self.set_qss('normal')

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        if event.button() == Qt.LeftButton:
            self.set_qss("check")

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        if event.button() == Qt.LeftButton:
            self.clicked.emit()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = PushButton_icon_with_label_bottom()
    window.show()
    sys.exit(app.exec_())

