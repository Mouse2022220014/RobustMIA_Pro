from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import *
import sys

class Introduce_Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        # 创建中心窗口
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        central_widget = QWidget(self)


        self.layout.addWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)

        # 建立滚动条
        scroll_area = QScrollArea(self)
        scroll_area.setWidgetResizable(True)
        scrollable_widget = QWidget(self)
        scrollable_widget.setObjectName('scrollable_widget')
        scrollable_layout = QVBoxLayout(scrollable_widget)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)


        # 建立4个frame
        self.frame1 = QWidget(self)
        self.frame2 = QWidget(self)
        self.frame3 = QWidget(self)
        self.frame4 = QWidget(self)
        self.frame1.setObjectName("frame_first")
        self.frame2.setObjectName("frame_second")
        self.frame3.setObjectName("frame_third")
        self.frame4.setObjectName("frame_forth")

        # 添加frame里的变量
        self.frame1.setFixedHeight(300)
        self.frame2.setFixedHeight(160)

        # 设置按钮
        self.pushbutton_test = QPushButton("开始测试", self)
        self.pushbutton_test_2 = QPushButton("进入测试", self)
        self.pushbutton_look = QPushButton("查看使用指南", self)


        # QSS
        self.frame1.setStyleSheet(" image: url(':/image/res/banner图@1x.png');"
                                  " background-size: cover;"
                                  " background: transparent;")
        self.frame2.setStyleSheet("background: transparent;")
        self.frame4.setStyleSheet("background: transparent;")
        self.pushbutton_test.setStyleSheet("QPushButton{"
                                           "min-width:128px;"
                                           "min-height:52px;"
                                           "background: #0098e1;"
                                           "border-radius:10px;"
                                           "font-size:18px;"
                                           "image:none;"
                                           "color:white;"
                                           "font-weight:bold;}"
                                           "QPushButton:hover{"
                                           "background:#329bce;"
                                           "font-size:22px;}"
                                           "QPushButton:pressed{"
                                           "background:#126891;}")
        self.pushbutton_look.setStyleSheet("QPushButton{"
                                           "min-width:168px; min-height: 54px;"
                                           "border: 1px solid #0098e1;"
                                           "border-radius:27px;"
                                           "background: transparent;"
                                           "font-size: 18px;"
                                           "color:#0298e1;"
                                           "font-weight:bold;}"
                                           "QPushButton:hover{"
                                           "background:rgba(2, 152, 225, 0.2);"
                                           "font-size:22px;}"
                                           "QPushButton:pressed{"
                                           "background:rgba(2, 152, 225, 0.45);}")
        self.pushbutton_test_2.setStyleSheet("QPushButton{"
                                             "min-width:168px;"
                                             "min-height:54px;"
                                             "background: #0098e1;"
                                             "border-radius:27px;"
                                             "font-size:18px;"
                                             "color: #ffffff;"
                                             "font-weight:bold;}"
                                             "QPushButton:hover{"
                                             "background:#329bce;"
                                             "font-size:22px;}"
                                             "QPushButton:pressed{"
                                             "background:#126891;}")
        central_widget.setStyleSheet(
            "background: transparent;"
            "border:none;")
        # 在滚动容器内布置frame
        scrollable_layout.addWidget(self.frame1)
        scrollable_layout.addWidget(self.frame2)
        scrollable_layout.addWidget(self.frame3)
        scrollable_layout.addSpacing(70)
        scrollable_layout.addWidget(self.frame4)

        # 将scrollable_widget设置为滚动区域的widget
        scroll_area.setWidget(scrollable_widget)

        # 将滚动区域添加到主布局
        layout.addWidget(scroll_area)

        # 运行函数
        self.init_Frame_1()
        self.init_Frame_2()
        self.init_Frame_3()
        self.init_Frame_4()

        # 设置中心窗口
        self.setGeometry(220, 25, 1350, 750)

        with open("./client/qss/RobustMIA_new.qss") as f:
            self.setStyleSheet(f.read())

    def init_Frame_1(self):
        # 建立一个水平布局
        main_layout = QHBoxLayout(self.frame1)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # 建立一个垂直布局
        label_layout = QVBoxLayout()
        label_layout.setContentsMargins(0,0,0,0)

        # 建立label
        label_tip1 = QLabel("医学影像AI安全性测试软件", self)
        label_tip1.setObjectName("label_tip1")

        label_tip2 = QLabel("深度学习在医疗诊断等领域取得了较为成功的应用，然而，图像分类作为上述应用中的一项\n\n"
                            "基础视觉任务，正遭受着对抗攻击等技术手段带来的 巨大安全隐患。提高深度学习模型抵御\n\n"
                            "对抗攻击的能力（即鲁棒性）成为有效缓解该问题的可行技术途径。", self)
        label_tip2.setObjectName("label_tip2")



        # 添加按钮水平布局
        pushbutton_layout = QHBoxLayout()

        # 绑定按钮
        pushbutton_layout.addWidget(self.pushbutton_test)
        pushbutton_layout.addSpacing(1190)

        # 添加总体布局
        label_layout.addWidget(label_tip1)
        label_layout.addWidget(label_tip2)
        label_layout.addLayout(pushbutton_layout)

        main_layout.addStretch(2)
        main_layout.addLayout(label_layout)
        main_layout.addStretch(2)

        # QSS
        label_tip1.setStyleSheet("min-width: 391px;"
                                 "min-height:32px;"
                                 "font-weight:bold;"
                                 "font-size: 32px;"
                                 "line-height:47px;"
                                 "background: transparent;"
                                 "image: none;"
                                 "color:white;")
        label_tip2.setStyleSheet("min-width: 726px;"
                                 "min-height: 99px;"
                                 "font-size:20px;"
                                 "color: rgba(255, 255, 255, 125);"
                                 "line-height: 5px;"
                                 "background: transparent;"
                                 "padding-bottom: 10px;"
                                 "image:none;")

    def init_Frame_2(self):
        # 建立垂直布局
        main_layout = QHBoxLayout(self.frame2)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # 建立label
        label_tip1 = QLabel("功能介绍", self)
        label_tip2 = QLabel("深度学习在医疗诊断等领域取得了较为成功的应用，然而，图像分类作为上述应用中的一项基础\n"
                            "                             视觉任务，正遭受着对抗攻击等技术手段带来的巨大安全隐患.", self)

        # 建立label垂直布局
        label_layout = QVBoxLayout()

        # 添加布局
        label_layout.addWidget(label_tip1)
        label_layout.addWidget(label_tip2)

        main_layout.addStretch(1)
        main_layout.addLayout(label_layout)
        main_layout.addStretch(1)
        # QSS
        label_tip1.setStyleSheet("width:146px;"
                                 "height:36px;"
                                 "font-weight: bold;"
                                 "color:rgba(255, 255, 255, 210);"
                                 "font-size:34px;"
                                 "line-height:47px;"
                                 "padding-left:300px;"
                                 )
        label_tip2.setStyleSheet("width:788px;"
                                 "height:60px;"
                                 "color:rgba(255, 255, 255, 125);"
                                 "font-size:18px;"
                                 "text-align:center;")

    def init_Frame_3(self):
        # 建立垂直布局
        main_layout = QVBoxLayout(self.frame3)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # 建立五个frame
        frame1 = QFrame(self)
        frame2 = QFrame(self)
        frame3 = QFrame(self)
        frame4 = QFrame(self)
        frame5 = QFrame(self)

        # 建立五个icon和按钮
        icon_1 = QIcon(":/image/res/分类模型-Normal.png")
        icon_2 = QIcon(":/image/res/分割模型-Normal.png")
        icon_3 = QIcon(":/image/res/检测模型-Normal.png")
        icon_4 = QIcon(":/image/res/模型文件-Normal.png")
        icon_5 = QIcon(":/image/res/数据文件-Normal.png")
        label_1 = QLabel(self)
        label_2 = QLabel(self)
        label_3 = QLabel(self)
        label_4 = QLabel(self)
        label_5 = QLabel(self)

        label_1.setPixmap(icon_1.pixmap(100, 100))
        label_2.setPixmap(icon_2.pixmap(100, 100))
        label_3.setPixmap(icon_3.pixmap(100, 100))
        label_4.setPixmap(icon_4.pixmap(100, 100))
        label_5.setPixmap(icon_5.pixmap(100, 100))
        label_1.setAlignment(Qt.AlignCenter)
        label_2.setAlignment(Qt.AlignCenter)
        label_3.setAlignment(Qt.AlignCenter)
        label_4.setAlignment(Qt.AlignCenter)
        label_5.setAlignment(Qt.AlignCenter)

        # 建立label
        label_1_1 = QLabel("分类模型", self)
        label_2_2 = QLabel("分割模型", self)
        label_3_3 = QLabel("检测模型", self)
        label_4_4 = QLabel("模型文件", self)
        label_5_5 = QLabel("数据文件", self)
        label_1_1_1 = QLabel("用于将输入的医学图像分为\n不同的类别，以进行疾病诊\n断和预测。\n", self)
        label_2_2_2 = QLabel("用于将医学图像中的不同结\n构和组织区域分割出来，以\n便进行更详细和准确的疾病\n"
                         "评估和诊断。", self)
        label_3_3_3 = QLabel("用于检测医学图像中的病变\n或异常区域，以便医生可以\n在疾病早期进行干预和治\n疗。", self)
        label_4_4_4 = QLabel("模型文件指基于PyTorch的\nTorchScript模块包装模型\n文件，有益于高性能部署。\n", self)
        label_5_5_5 = QLabel("数据文件指的是用测试深度\n模型的数据集,平台需要一\n份测试集来作为测试的材料。\n", self)


        # 建立五个垂直布局
        frame1_layout = QVBoxLayout(frame1)
        frame2_layout = QVBoxLayout(frame2)
        frame3_layout = QVBoxLayout(frame3)
        frame4_layout = QVBoxLayout(frame4)
        frame5_layout = QVBoxLayout(frame5)

        # 给frame添加内容
        frame1_layout.addWidget(label_1)
        frame1_layout.addWidget(label_1_1)
        frame1_layout.addWidget(label_1_1_1)

        frame2_layout.addWidget(label_2)
        frame2_layout.addWidget(label_2_2)
        frame2_layout.addWidget(label_2_2_2)

        frame3_layout.addWidget(label_3)
        frame3_layout.addWidget(label_3_3)
        frame3_layout.addWidget(label_3_3_3)

        frame4_layout.addWidget(label_4)
        frame4_layout.addWidget(label_4_4)
        frame4_layout.addWidget(label_4_4_4)

        frame5_layout.addWidget(label_5)
        frame5_layout.addWidget(label_5_5)
        frame5_layout.addWidget(label_5_5_5)

        # 设置frame的长宽
        frame1.setFixedHeight(236)
        frame1.setFixedWidth(226)
        frame2.setFixedHeight(236)
        frame2.setFixedWidth(226)
        frame3.setFixedHeight(236)
        frame3.setFixedWidth(226)
        frame4.setFixedHeight(236)
        frame4.setFixedWidth(226)
        frame5.setFixedHeight(236)
        frame5.setFixedWidth(226)

        # 建立上下行水平布局
        up_layout = QHBoxLayout()
        down_layout= QHBoxLayout()

        # 添加frame
        up_layout.addSpacing(202)
        up_layout.addWidget(frame1)
        up_layout.addSpacing(150)
        up_layout.addWidget(frame2)
        up_layout.addSpacing(150)
        up_layout.addWidget(frame3)
        up_layout.addSpacing(202)

        down_layout.addSpacing(390)
        down_layout.addWidget(frame4)
        down_layout.addSpacing(150)
        down_layout.addWidget(frame5)
        down_layout.addSpacing(390)

        # 添加总体布局
        main_layout.addSpacing(20)
        main_layout.addLayout(up_layout)
        main_layout.addSpacing(40)
        main_layout.addLayout(down_layout)

        # QSS
        self.frame3.setStyleSheet("QWidget{"
                                  "background:transparent;"
                                  "}"
                                  "QFrame{"
                                  " border-radius:8px;"
                                  " background-color:rgba(150, 150, 150, 60);"
                                  " border: 1px solid rgba(255, 255, 255, 45);}"
                                  "QLabel{"
                                  " background: transparent;"
                                  " background-size: cover;"
                                  " text-align: center;"
                                  " border:none;}")
        style_label_n_n = "width: 82px; height: 20px; font-size: 20px; " \
                          "color: rgba(255,255,255,220); padding-left:55px;font-weight:bold"
        style_label_n_n_n = "width:182px; color: rgba(255, 255, 255, 150); font-size:16px;"


        label_1_1.setStyleSheet(style_label_n_n)
        label_2_2.setStyleSheet(style_label_n_n)
        label_3_3.setStyleSheet(style_label_n_n)
        label_4_4.setStyleSheet(style_label_n_n)
        label_5_5.setStyleSheet(style_label_n_n)
        label_1_1_1.setStyleSheet(style_label_n_n_n)
        label_2_2_2.setStyleSheet(style_label_n_n_n)
        label_3_3_3.setStyleSheet(style_label_n_n_n)
        label_4_4_4.setStyleSheet(style_label_n_n_n)
        label_5_5_5.setStyleSheet(style_label_n_n_n)

    def init_Frame_4(self):
        # 建立水平布局
        main_layout = QHBoxLayout(self.frame4)
        main_layout.setContentsMargins(0, 0, 0, 0)



        # 绑定按钮
        main_layout.addSpacing(492)
        main_layout.addWidget(self.pushbutton_look)
        main_layout.addSpacing(62)
        main_layout.addWidget(self.pushbutton_test_2)
        main_layout.addSpacing(491)







if __name__ == '__main__':
    app = QApplication(sys.argv)
    with open("style.qss", encoding='UTF-8') as f:
        app.setStyleSheet(f.read())
    window =  Introduce_Page()
    window.show()
    sys.exit(app.exec_())