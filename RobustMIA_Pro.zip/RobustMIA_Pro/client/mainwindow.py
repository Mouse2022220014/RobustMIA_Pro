import sys
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QFileDialog, QPushButton, QHBoxLayout, QVBoxLayout,
                             QLabel, QProgressBar, QTableWidgetItem, QHeaderView, QTableWidget)
from PyQt5.QtCore import pyqtSignal, QPropertyAnimation, QSize, QSequentialAnimationGroup, QRect, pyqtProperty, Qt, \
    QRectF
from PyQt5.QtGui import QPixmap, QLinearGradient, QPainter, QColor, QIcon, QPainterPath, QBrush
import webbrowser
import os

# 我的模块
from client.RobustMIA3 import *
from client.thread import TestThread, TestThread_socket, LoadingThread
from client.RobustMIA_TitleBar import *
from client.IP_widget_show import *

from file.file_receive import FileReceive
from client.Result import ResultPage
from data_db.history_score import *
import client.RobustMIA_res_rc


def text_center(text):
    item = QTableWidgetItem()
    item.setText(text)

    item.setTextAlignment(Qt.AlignCenter)
    return item

class HomePage(QMainWindow):
    back_to_homepage = pyqtSignal()

    method = ["", "", "高斯噪声", "散斑噪声", "ELD噪声",
              "高斯模糊", "运动模糊", "JPEG压缩", "像素化",
              "亮度（上升）", "亮度（下降）", "对比度（上升）", "对比度（下降）", "饱和度（上升）", "饱和度（下降）",
              "色度（红）", "色度（绿）", "色度（蓝）",
              "旋转", "平移（上）", "平移（下）", "平移（左）", "平移（右）",
              "缩放（x）", "缩放（y）", "缩放（xy）",
              "畸变", "畸变",
              "FGSM (目标)", "FGSM (非目标)", "MIM (目标)", "MIM (非目标)", "PGD (目标)", "PGD (非目标)",
              "CW (目标)", "CW (非目标)", "DDN (目标)", "DDN (非目标)", "ERFGSM(目标)", "ERFGSM(非目标)", "", "", "", "", "", "", "", "", "", ""]

    def __init__(self, session):
        super().__init__()
        self.session = session
        # 自定义标题栏
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        TitleWindow = CustomTitleBar()
        self.setMenuWidget(TitleWindow)

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.setWindowTitle("RobustMIA Pro")

        self.resize(1600, 900)

        self.test_thread = None
        self.result_pages = []  # 如何清理呢?
        self.is_testing = False

        self.ip_Widget = IP_widget_show(self)
        self.ip_Widget.hide()


        self.loading_thread = LoadingThread()
        self.loading_thread.loading_signal.connect(self.update_loading_label)
        # 回到首页
        self.ui.stackedWidget.setCurrentIndex(0)
        self.ui.stackedWidget_2.setCurrentIndex(0)

        # 为自定义控件绑定初始icon及Text
        self.pushButton_setIcon_menu()
        self.pushButton_setIcon_model()
        self.pushButton_setText()
        self.ui.pushButton_model.set_icon(":/icon/res/步骤图/model_file_default.png")
        self.ui.pushButton_data.set_icon(":/icon/res/步骤图/data_file_default.png")

        self.ui.pushButton_home.set_qss('check')

        # 按钮信号
        # 模型类型
        self.ui.pushButton_classification.clicked.connect(self.model_type_classification)
        self.ui.pushButton_segmentation.clicked.connect(self.model_type_segmentation)
        self.ui.pushButton_detection.clicked.connect(self.model_type_detection)

        # 上传文件
        self.ui.pushButton_model.clicked.connect(self.upload_model)
        self.ui.pushButton_data.clicked.connect(self.upload_data)

        # 菜单栏
        self.ui.pushButton_test.clicked.connect(self.stackWidget_test)
        self.ui.pushButton_home.clicked.connect(self.stackWidget_home)
        self.ui.pushButton_document.clicked.connect(self.stackWidget_document)
        self.ui.pushButton_result.clicked.connect(self.stackWidget_result)
        self.ui.widget_3.pushbutton_test.clicked.connect(self.stackWidget_test)
        self.ui.widget_3.pushbutton_test_2.clicked.connect(self.stackWidget_test)
        self.ui.widget_3.pushbutton_look.clicked.connect(self.stackWidget_document)

        self.ui.pushButton_test.enter.connect(self.ui.pushButton_test.set_qss)
        self.ui.pushButton_home.enter.connect(self.ui.pushButton_home.set_qss)
        self.ui.pushButton_document.enter.connect(self.ui.pushButton_document.set_qss)
        self.ui.pushButton_result.enter.connect(self.ui.pushButton_result.set_qss)

        self.ui.pushButton_backhomepage.clicked.connect(self.stackWidget_home)
        self.ui.pushButton_backhomepage_2.clicked.connect(self.stackWidget_home)

        # 开始&重置
        self.ui.pushButton_start.clicked.connect(self.button_clicked_test)
        self.ui.pushButton_reset.clicked.connect(self.button_clicked_reset)

        # 结果导出
        self.ui.tab_classification.clicked.connect(self.tab_classification_clicked)
        self.ui.tab_segmentation.clicked.connect(self.tab_segmentation_clicked)
        self.ui.tab_detection.clicked.connect(self.tab_detection_clicked)
        self.ui.pushButton_export.clicked.connect(self.button_clicked_export)

        # ip
        self.ui.pushButton_ip.clicked.connect(self.pushButton_ip_clicked)
        self.ip_Widget.ui.pushButton_cancel.clicked.connect(self.line_edit_clear)
        self.ip_Widget.ui.pushButton_preserve.clicked.connect(self.line_edit_save)

        # 连接按钮的点击信号到 ResultPage 的方法
        TitleWindow.minimize_button.clicked.connect(self.showMinimized)
        TitleWindow.maximize_button.clicked.connect(self.toggleMaximize)

    def toggleMaximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def paintEvent(self, event):
        path = QPainterPath()
        rect = QRectF(self.rect())
        path.addRoundedRect(rect, 10, 10)  # 设置弧度为 10
        painter = QPainter(self)
        painter.fillPath(path, QBrush(QColor("#42464d")))

    # 初始化icon
    def pushButton_setIcon_menu(self, select=None):
        self.ui.pushButton_test.set_icon(":/icon/res/2-侧边栏icon切图/1-Normal/测试中心icon@3x-Normal.png")
        self.ui.pushButton_document.set_icon(":/icon/res/2-侧边栏icon切图/1-Normal/使用指南icon@3x-Normal.png")
        self.ui.pushButton_result.set_icon(":/icon/res/2-侧边栏icon切图/1-Normal/查看结果icon@3x-Normal.png")
        self.ui.pushButton_home.set_icon(":/icon/res/2-侧边栏icon切图/1-Normal/首页Normal.png")

        self.ui.pushButton_home.select = False
        self.ui.pushButton_result.select = False
        self.ui.pushButton_test.select = False

        if select == 'home':
            self.ui.pushButton_home.set_icon(":/icon/res/2-侧边栏icon切图/3-Click/首页Click.png")
            self.ui.pushButton_home.set_qss('check')
            self.ui.pushButton_home.select = True
            self.ui.pushButton_test.set_qss()
            self.ui.pushButton_result.set_qss()

        elif select == 'test':
            self.ui.pushButton_test.set_icon(":/icon/res/2-侧边栏icon切图/3-Click/测试中心icon@3x-Click.png")
            self.ui.pushButton_test.set_qss('check')
            self.ui.pushButton_test.select = True
            self.ui.pushButton_home.set_qss()
            self.ui.pushButton_result.set_qss()

        elif select == 'result':
            self.ui.pushButton_result.set_icon(":/icon/res/2-侧边栏icon切图/3-Click/查看结果icon@3x-Click.png")
            self.ui.pushButton_result.set_qss('check')
            self.ui.pushButton_result.select = True
            self.ui.pushButton_test.set_qss()
            self.ui.pushButton_home.set_qss()


    def pushButton_setIcon_model(self, select=None):
        self.ui.pushButton_classification.set_icon(":/icon/res/步骤图/分类_blue.png")
        self.ui.pushButton_segmentation.set_icon(":/icon/res/步骤图/分割 _blue.png")
        self.ui.pushButton_detection.set_icon(":/icon/res/步骤图/检测_blue.png")

        if select == 'classification':
            self.ui.pushButton_classification.set_icon(":/icon/res/步骤图/分类_blue.png")
            self.ui.pushButton_classification.set_qss('check')
            self.ui.pushButton_segmentation.set_qss()
            self.ui.pushButton_detection.set_qss()

        elif select == 'segmentation':
            self.ui.pushButton_segmentation.set_icon(":/icon/res/步骤图/分割 _blue.png")
            self.ui.pushButton_segmentation.set_qss('check')
            self.ui.pushButton_classification.set_qss()
            self.ui.pushButton_detection.set_qss()

        elif select == 'detection':
            self.ui.pushButton_detection.set_icon(":/icon/res/步骤图/检测_blue.png")
            self.ui.pushButton_detection.set_qss('check')
            self.ui.pushButton_segmentation.set_qss()
            self.ui.pushButton_classification.set_qss()

        elif select == 'model':
            self.ui.pushButton_model.set_icon(":/icon/res/步骤图/model_file.png")
            self.ui.pushButton_model.set_qss('check')

        elif select == 'data':
            self.ui.pushButton_data.set_icon(":/icon/res/步骤图/data_file.png")
            self.ui.pushButton_data.set_qss('check')

    def pushButton_setText(self):
        self.ui.pushButton_test.set_text("测试中心")
        self.ui.pushButton_home.set_text("首页")
        self.ui.pushButton_document.set_text("使用指南")
        self.ui.pushButton_result.set_text("查看结果")
        self.ui.pushButton_classification.set_text("分类模型")
        self.ui.pushButton_segmentation.set_text("分割模型")
        self.ui.pushButton_detection.set_text("检测模型")
        self.ui.pushButton_model.set_text("模型文件")
        self.ui.pushButton_data.set_text("数据文件")

    # 切换页面
    def stackWidget_home(self):
        self.ui.stackedWidget.setCurrentIndex(0)
        self.pushButton_setIcon_menu('home')

    def stackWidget_document(self):
        webbrowser.open("file://" + os.path.realpath("template/document.html"))

    def stackWidget_test(self):
        self.ui.stackedWidget.setCurrentIndex(1)
        self.ui.icon_true.setStyleSheet("image: url(':/icon/res/5-小icon区/对钩.png');")
        self.ui.step.setStyleSheet("color: #0298e1;")
        if self.is_testing is False:
            self.ui.stackedWidget_2.setCurrentIndex(0)
        else:
            self.ui.stackedWidget_2.setCurrentIndex(2)

        self.pushButton_setIcon_menu('test')

    def stackWidget_result(self):
        self.ui.stackedWidget.setCurrentIndex(2)
        self.pushButton_setIcon_menu('result')

        data_classification = get_history_score_with_type('classification')
        self.table_Widget_result(data_classification)

    def tab_classification_clicked(self):
        self.ui.tab_classification.setChecked(True)
        self.ui.tab_segmentation.setChecked(False)
        self.ui.tab_detection.setChecked(False)
        data_classification = get_history_score_with_type('classification')
        self.table_Widget_result(data_classification)

    def tab_segmentation_clicked(self):
        self.ui.tab_classification.setChecked(False)
        self.ui.tab_segmentation.setChecked(True)
        self.ui.tab_detection.setChecked(False)
        data_segmentation = get_history_score_with_type('segmentation')
        self.table_Widget_result(data_segmentation)

    def tab_detection_clicked(self):
        self.ui.tab_classification.setChecked(False)
        self.ui.tab_segmentation.setChecked(False)
        self.ui.tab_detection.setChecked(True)
        data_detection = get_history_score_with_type('detection')
        self.table_Widget_result(data_detection)

    # 模型选择
    def model_type_detection(self):
        self.session['model_type'] = 'detection'
        self.pushButton_setIcon_model('detection')
        self.ui.stackedWidget_2.setCurrentIndex(1)
        self.ui.icon_true_2.setStyleSheet("image: url(':/icon/res/5-小icon区/对钩.png');")
        self.ui.step_2.setStyleSheet("color: #0298e1;")

    def model_type_segmentation(self):
        self.session['model_type'] = 'segmentation'
        self.pushButton_setIcon_model('segmentation')
        self.ui.stackedWidget_2.setCurrentIndex(1)
        self.ui.icon_true_2.setStyleSheet("image: url(':/icon/res/5-小icon区/对钩.png');")
        self.ui.step_2.setStyleSheet("color: #0298e1;")

    def model_type_classification(self):
        self.session['model_type'] = 'classification'
        self.pushButton_setIcon_model('classification')
        self.ui.stackedWidget_2.setCurrentIndex(1)
        self.ui.icon_true_2.setStyleSheet("image: url(':/icon/res/5-小icon区/对钩.png');")
        self.ui.step_2.setStyleSheet("color: #0298e1;")


    def button_clicked_back(self):
        self.back_to_homepage.emit()
        self.hide()

    # 数据上传
    def upload_data(self):
        file_dir = QFileDialog.getExistingDirectory(self)
        try:
            FileReceive.save_dir(file_dir, self.session['model_type'] + '/data', is_model=False)

        except Exception as e:
            print(e)
            self.error('数据集上传失败')
            return

        self.pushButton_setIcon_model('data')

    def upload_model(self):
        file_dir = QFileDialog.getExistingDirectory(self)
        if file_dir:
            try:
                _, model_name = FileReceive.save_dir(file_dir, self.session['model_type'] + '/model',
                                                     is_model=True)
                self.session['model_name'] = model_name

            except Exception as e:
                print(e)
                self.error('模型上传失败')
                return
        self.pushButton_setIcon_model('model')


    def button_clicked_reset(self):
        pass

        # self.ui.lineEdit_ip.setText('')

    def pushButton_ip_clicked(self):
        self.ip_Widget.show()

    def line_edit_clear(self):
        self.ip_Widget.ui.lineEdit.setText("")

    def line_edit_save(self):
        ip = self.ip_Widget.ui.lineEdit.text()
        self.session['server_ip'] = ip

    def button_clicked_test(self):
        # 稳定性测试Classify_test <- 原始、攻击图像预测结果Classify_prediction <- 拿到原始数据ImageLoader_classify,
        #                                                                   模型预测方法 Model_handler
        #                                                                   图像攻击方法 Attack

        # 其他线程
        # 判断参数填写是否完整...

        # 将ip存入session
        # ip = self.ui.lineEdit_ip.text()
        # if ip == '':
        #     self.session['server_ip'] = None
        # else:
        #     self.session['server_ip'] = ip
        # 制作视频
        self.session['server_ip'] = None

        # 判断本机测试还是服务器测试
        if self.session['server_ip'] is None:
            print("no socket")
            self.ui.progressBar.setValue(0)
            self.ui.stackedWidget_2.setCurrentIndex(2)
            self.ui.icon_true_3.setStyleSheet("image: url(':/icon/res/5-小icon区/对钩.png');")
            self.ui.step_3.setStyleSheet("color: #0298e1;")
            self.test_thread = TestThread(self.session)
        else:
            print("socket")
            # 还没做
            self.ui.stackedWidget_2.setCurrentIndex(3)
            self.loading_thread.is_running = True
            self.loading_thread.start()
            self.test_thread = TestThread_socket(self.session)

        self.test_thread.finish.connect(self.getfinish)
        self.test_thread.progress_emit.connect(self.progress)
        self.test_thread.start()

        # 正在测试状态
        self.is_testing = True

    def update_loading_label(self, text):
        # self.ui.label.setText(text)
        pass

    def getfinish(self, session: dict):
        # 更新页面
        print("测试完成")
        result_page = ResultPage(session)
        self.result_pages.append(result_page)
        result_page.resize(1360, 765)
        result_page.show()

        insert_history_score(session)
        self.stackWidget_result()
        self.button_clicked_reset()

        # 测试状态
        self.is_testing = False

    # def table_Widegt_show(self, data):
    #     # 设置历史记录表格的行和列
    #     self.ui.tableWidget_time.setRowCount(len(data))
    #     self.ui.tableWidget_time.setColumnCount(5)
    #     # 获取水平标题栏
    #     header = self.ui.tableWidget_time.horizontalHeader()
    #     # 设置拉伸模式为填满整个水平空间
    #     header.setSectionResizeMode(QHeaderView.Stretch)
    #     # 添加数据
    #     for row, item in enumerate(data):
    #         for column, value in enumerate(item):
    #             if type(value) == float:
    #                 value = str(int(value))
    #             value = text_center(value)
    #             self.ui.tableWidget_time.setItem(row, column, QTableWidgetItem(value))
    #             color = QColor("white")
    #             self.ui.tableWidget_time.item(row, column).setBackground(color)

    # def table_Widget_result(self, data):
    #     # 水平标题栏属性
    #     header = self.ui.tableWidget.horizontalHeader()
    #     header.setSectionResizeMode(QHeaderView.Stretch)
    #     self.ui.tableWidget.setRowCount(len(data))
    #     self.ui.tableWidget.setColumnCount(4)
    #     #  添加数据
    #     for row, item in enumerate(data):
    #         for column, value in enumerate(item):
    #             if type(value) == float:
    #                 value = int(value)
    #             value = str(value)
    #             value = text_center(value)
    #             self.ui.tableWidget.setItem(row, column, QTableWidgetItem(value))
    #             if row % 2 == 0:
    #                 self.ui.tableWidget.item(row, column).setBackground(QColor('white'))
    #             else:
    #                 self.ui.tableWidget.item(row, column).setBackground(QColor('rgba(255, 255, 255, 0.05)'))

    def table_Widget_result(self, data):
        self.ui.tableWidget.setRowCount(len(data))
        self.ui.tableWidget.setColumnCount(4)
        self.ui.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        # 水平标题栏属性
        self.ui.tableWidget.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.ui.tableWidget.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.ui.tableWidget.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.ui.tableWidget.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        # 获取表宽度
        total_width = self.ui.tableWidget.width()
        # 按照比例设置每列的宽度
        self.ui.tableWidget.horizontalHeader().resizeSection(0, total_width * 4 / 10)  # 模型
        self.ui.tableWidget.horizontalHeader().resizeSection(1, total_width * 2 / 10)  # 得分
        self.ui.tableWidget.horizontalHeader().resizeSection(2, total_width * 3 / 10)  # 时间
        self.ui.tableWidget.horizontalHeader().resizeSection(3, total_width * 4 / 10)  # 测试id

        self.ui.tableWidget.horizontalHeader().setVisible(False)
        self.ui.tableWidget.verticalHeader().setDefaultSectionSize(42)  # 行高
        self.ui.tableWidget.verticalHeader().setSectionResizeMode(0, 36)

        header_name = ('模型名称', '模型得分', '测试时间', '测试id')
        color_1 = QColor(0,0,0,13)
        color_2 = QColor(255,255,255,13)
        font = QFont("Microsoft YaHei", 18)

        for i in range(4):
            header_item = QTableWidgetItem(header_name[i])
            header_item.setBackground(QColor(255,255,255,38))
            header_item.setFont(font)
            header_item.setTextAlignment(Qt.AlignCenter)
            self.ui.tableWidget.setItem(0, i, header_item)

        # 添加数据

        for row, item in enumerate(data):
            for column, value in enumerate(item):
                if type(value) == float:
                    value = int(value)
                value = str(value)
                value = text_center(value)
                q_item = QTableWidgetItem(value)
                q_item.setFont(font)
                # q_item.setTextColor(QColor(255,255,255,165))
                if row % 2 == 0:
                    q_item.setBackground(color_1)
                else:
                    q_item.setBackground(color_2)

                self.ui.tableWidget.setItem(row + 1, column, q_item)

    def error(self, message):
        # 处理错误信息
        print(message)

    def progress(self, testing_index):
        if testing_index == 0:
            self.ui.stackedWidget_2.setCurrentIndex(2)
            self.loading_thread.is_running = False

        self.ui.frame.label2.setText(self.method[0+testing_index])
        self.ui.frame.project_label.setText(self.method[1+testing_index])
        self.ui.frame.label3.setText(self.method[2 + testing_index])
        self.ui.frame.label4.setText(self.method[3+testing_index])
        self.ui.frame.label5.setText(self.method[4+testing_index])
        self.ui.frame.label6.setText(self.method[5 + testing_index])
        self.ui.frame.label7.setText(self.method[6 + testing_index])
        self.ui.frame.label8.setText(self.method[7 + testing_index])

        # 更新进度条
        self.ui.progressBar.setValue(int(100 * (testing_index/36)) - 1)

    # 导出数据
    def button_clicked_export(self):
        # 获取模型测试id
        id_int = self.ui.tableWidget.selectedItems()[3].text()

        id_int = int(id_int)

        # 获取数据
        data_dict = {}
        data = get_result_data(id_int)[0]

        # 解包
        data_dict['model_name'] = data[0]
        data_dict['score_sum'] = int(data[1])
        data_dict['radar_data'] = json.loads(data[2])
        data_dict['point_line_data'] = json.loads(data[3])

        # 导出到结果页
        result_page = ResultPage(data_dict)
        self.result_pages.append(result_page)
        result_page.resize(1600, 900)
        result_page.show()


