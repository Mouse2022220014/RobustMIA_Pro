from PyQt5.QtCore import Qt, QPoint
from PyQt5.QtWidgets import *
from client.IP_widget import *
class IP_widget_show(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlag(Qt.FramelessWindowHint)
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.center()
        self.hide()
        # 添加用于跟踪鼠标拖动的变量
        self.startMousePos = None
        self.startWindowPos = None
        self.movePos = QPoint(0, 0)


    def center(self):
        # 获取屏幕的尺寸
        screen_geo = QApplication.desktop().screenGeometry()

        # 获取窗口尺寸
        widget_geo = self.frameGeometry()

        # 计算居中的位置
        center_point = screen_geo.center()
        widget_geo.moveCenter(center_point)

        # 移动窗口到居中位置
        x = int(widget_geo.topLeft().x() - 617/4)
        y = int(widget_geo.topLeft().y() - 227/2)

        self.move(x, y)
