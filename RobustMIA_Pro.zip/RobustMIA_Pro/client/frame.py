import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *


class ProgressFrame(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)


class ProjectFrame(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)

        self.project_label = QLabel(self)
        self.project_label.setObjectName('project_label')
        self.project_label.setText("添加噪声")

        self.project_label.setAlignment(Qt.AlignCenter)

        self.linear_gradient = QLinearGradient(0, 0, 255, 0)
        self.linear_gradient.setColorAt(0, QColor(9, 118, 245, 0))
        self.linear_gradient.setColorAt(1, QColor("#0298e1"))

        # 绘制动画
        self.filled_rect = 0.0
        self.animation_rect = QPropertyAnimation(self, b"myrect")
        self.animation_rect.setStartValue(0)
        self.animation_rect.setEndValue(1)
        self.animation_rect.setDuration(300)

        self.pause_animation = QPauseAnimation(300)

        self.animation_rect_back = QPropertyAnimation(self, b"myrect")
        self.animation_rect_back.setStartValue(1)
        self.animation_rect_back.setEndValue(0)
        self.animation_rect_back.setDuration(500)

        self.anim_group = QSequentialAnimationGroup(self)
        self.anim_group.addAnimation(self.animation_rect)
        self.anim_group.addAnimation(self.pause_animation)
        self.anim_group.addAnimation(self.animation_rect_back)
        self.anim_group.setLoopCount(-1)
        self.anim_group.start()

        self.label2 = QLabel("平移（左）", self)
        self.label3 = QLabel("平移（右）", self)

        self.label4 = QLabel("旋转", self)
        self.label5 = QLabel("缩放", self)

        self.label6 = QLabel("模糊", self)
        self.label7 = QLabel("模糊", self)
        self.label8 = QLabel("模糊", self)

        self.label2.setAlignment(Qt.AlignCenter)
        self.label3.setAlignment(Qt.AlignCenter)
        self.label4.setAlignment(Qt.AlignCenter)
        self.label5.setAlignment(Qt.AlignCenter)
        self.label6.setAlignment(Qt.AlignCenter)
        self.label7.setAlignment(Qt.AlignCenter)
        self.label8.setAlignment(Qt.AlignCenter)

        self.layout.addWidget(self.label2, 1)
        self.layout.addWidget(self.project_label, 1)
        self.layout.addWidget(self.label3, 1)
        self.layout.addWidget(self.label4, 1)
        self.layout.addWidget(self.label5, 1)
        self.layout.addWidget(self.label6, 1)
        self.layout.addWidget(self.label7, 1)
        self.layout.addWidget(self.label8, 1)


        self.layout.setSpacing(0)
        self.layout.setContentsMargins(0, 0, 0, 0)

        with open("./client/qss/frame.qss") as f:
            self.setStyleSheet(f.read())

    def paintEvent(self, event):
        super().paintEvent(event)
        rect = self.project_label.geometry()
        rect.setWidth(int(rect.width() * self.filled_rect))
        painter = QPainter(self)
        painter.fillRect(rect, self.linear_gradient)

    # 函数名是任意的，只是作为回调
    def get_myrect(self):
        return self.filled_rect

    def set_myrect(self, value):
        self.filled_rect = value
        self.update()


    # 添加属性，注意放的位置
    myrect = pyqtProperty(float, fget=get_myrect, fset=set_myrect)

