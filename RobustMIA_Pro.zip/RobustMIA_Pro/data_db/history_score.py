import sqlite3
from datetime import datetime
import json


def insert_history_score(session):
    username = session['username']
    model_type = session['model_type']
    model_name = session['model_name'].split('.')[0]
    score = session['score_sum']
    radar_data = json.dumps(session['radar_data'])
    point_line_data = json.dumps(session['point_line_data'])
    test_time = datetime.now()
    test_time = test_time.strftime("%Y-%m-%d")
    conn = sqlite3.connect('./data_db/history_score.db')
    c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS HistoryScore(
    username text, 
    model_type text, 
    model_name text, 
    score real, 
    radar_data text, 
    point_line_data text, 
    test_time text,
    id INTEGER PRIMARY KEY)
    ''')

    c.execute("INSERT INTO HistoryScore(username, model_type, model_name, score, radar_data, point_line_data, test_time) VALUES (?,?,?,?,?,?,?)",
              (username, model_type, model_name, score, radar_data, point_line_data, test_time))

    conn.commit()
    c.close()
    conn.close()


def get_history_score():
    conn = sqlite3.connect('./data_db/history_score.db')
    c = conn.cursor()
    c.execute('SELECT username, model_type, model_name, score, test_time FROM HistoryScore LIMIT 20')
    data = c.fetchall()
    c.close()
    conn.close()
    return data


def get_history_score_with_type(model_type):
    conn = sqlite3.connect('./data_db/history_score.db')
    c = conn.cursor()
    c.execute('SELECT model_name, score, test_time, id FROM HistoryScore WHERE model_type = ?', (model_type,))
    data = c.fetchall()
    c.close()
    conn.close()
    return data


def get_result_data(id: int):
    conn = sqlite3.connect('./data_db/history_score.db')
    c = conn.cursor()
    c.execute("SELECT model_name, score, radar_data, point_line_data FROM HistoryScore WHERE id = ?", (id,))
    data = c.fetchall()
    c.close()
    conn.close()
    return data


if __name__ == '__main__':
    test_time = datetime.now()
    test_time = test_time.strftime("%Y-%m-%d")

